# LLM-to-LLM Communication Research

Research conducted 2026-04-11. All experiments run from the Foreman project.

## Table of Contents

1. [Problem Statement](#problem-statement)
2. [Concepts Developed](#concepts-developed)
3. [Experiment Timeline](#experiment-timeline)
4. [Experiment Results](#experiment-results)
5. [Prior Art](#prior-art)
6. [Architecture Council Verdict](#architecture-council-verdict)
7. [Conclusions](#conclusions)
8. [Open Questions](#open-questions)

---

## Problem Statement

Foreman is an MCP server where an Opus "pit-boss" delegates code tasks to
Sonnet "workers" via text briefs. The current briefs are prose markdown —
~300 tokens of natural language describing what to implement, where, and
what constraints to follow.

**Question:** Can we design a denser, more effective encoding for this
LLM-to-LLM communication? One that activates the right conceptual
neighbourhoods in the receiving model with less overhead?

**Constraint:** The encoding must survive real transport — bash pipes,
CLI arguments, MCP tool parameters, Agent tool prompts. No access to
model internals or latent states.

---

## Concepts Developed

### 1. TOON (Terse Operation-Oriented Notation)

The first attempt. A rigid @-sigil format where each sigil encodes one
dimension of a code change:

```
#TOON/1
@F zod|mcp-tool|typescript          ← domain anchors
@S foreman-mcp/src/types.ts        ← file scope
@A structure|type-safety|export     ← reasoning axes

@Δa insert::WriteLedgerInputSchema+after
  export const X = z.object({...})  ← code payload

@! must_not::modify(existing)       ← constraints
@T vitest run tests/writeTools      ← verification
@? {code}                           ← expected reply shape
@σ 0.95                             ← confidence
@~ Prose fallback if sigils fail    ← gloss
```

**What TOON got right:**
- Dimensions as explicit structure
- Code payload as primary content
- Constraints separate from payload
- Verification as a declared field

**What TOON got wrong:**
- Rigid format with formal parser (models don't need parsers)
- Human-readable design (models don't care about readability)
- Fixed sigil vocabulary (models naturally extend notation)
- MORE expensive than markdown (+23% tokens on average)

**Status:** Historical. Superseded by Seed Pattern and LAP.

### 2. Seed Graph Notation

Discovered in Experiment 03. A notation for multi-model design
conversations where the first message establishes a pattern that
receiving models continue naturally.

```
TOPIC: <subject>
DIMS: [dimension1, dimension2, ...]
NODES: {
  concept_a: type1 | type2,
  concept_b: type3 + type4
}
EDGES: {
  concept_a --relationship--> concept_b,
  concept_c --causes--> concept_d
}
OPEN: {
  1: unresolved question?
  2: another question?
}
```

**Key finding:** Three different model architectures (Claude Opus,
Gemini 2.5 Flash, DeepSeek R1) continued this notation without being
told how. DeepSeek invented a new section (`CHALLENGED_EDGES:`) on its
own. The shared training prior for structured notation is universal
enough that one example establishes the protocol.

**Use case:** Peer-to-peer design collaboration between LLMs.
Not task delegation — idea exchange.

### 3. Seed Pattern (for task delegation)

A minimal task encoding where the structure itself is the spec:

```
TARGET: <file>
AFTER: <anchor>
OP: insert
---
<code payload>
---
GUARD: <what not to touch>
TEST: <verify command>
REPLY: <expected shape>
```

**Properties:**
- Cheapest format tested (-15% vs markdown)
- Works on every model including Codex CLI
- Never best, never worst — safe default
- No parser needed, models follow naturally

**Use case:** Code task delegation (pit-boss to worker).

### 4. LAP (Layered Activation Protocol)

The evolved concept. Not a format — a framework for constructing
LLM-to-LLM briefs where each layer targets different weights in the
receiving model.

**The 8 layers:**

| Layer | Purpose | Mechanism | Example |
|-------|---------|-----------|---------|
| **PRIME** | Narrow knowledge domain | Rare anchor terms activate specific manifolds | `distributed-systems, fixed-window-counter, round-robin-lb` |
| **ROLE** | Set behavioral mode | Like a system prompt — shifts overall processing | `You are tracing a production failure across 5 server instances` |
| **FOCUS** | Direct dimensional attention | Named axes the model should reason about | `[per-instance-behavior, timing-at-boundaries, fix-architecture]` |
| **ACTIVATE** | Turn UP specific capabilities | Explicit capability targeting | `step-by-step-trace, quantitative-reasoning, timing-diagrams` |
| **SUPPRESS** | Turn DOWN unhelpful defaults | Negation boundaries shape the manifold | `surface-labels, hand-waving, "it-depends", premature-solution` |
| **ANCHOR** | Pattern induction | Concrete example to reason from | `instance_A.counter["1.2.3.4"] = 0..100 (independent)` |
| **TASK** | The actual instruction | Natural language (models follow NL best) | `Explain why 5 independent rate limiters allow 5x over-admission` |
| **SHAPE** | Output constraints | What the response should look like | `causes with mechanism traces, fix with architecture, tradeoffs as table` |

**Key design principle:** Separate ACTIVATION (what weights to light up)
from INSTRUCTION (what to do) from SHAPING (what the output looks like).
Most prompts conflate all three. Separating them allows the pit-boss to
tune each independently per task type.

**Theoretical basis:**
- PRIME exploits sparse feature activation (Anthropic SAE research)
- ROLE exploits behavioural priming (instruction-tuning dynamics)
- ACTIVATE/SUPPRESS exploit the same mechanism as persona steering vectors
- ANCHOR exploits in-context learning / few-shot pattern induction
- TASK works best in natural language (proven: `@? {code}` failed where
  "Reply with just the code" succeeded)
- SHAPE constrains the output manifold

**Use case:** Any LLM-to-LLM delegation, with layers selected per task:
- Code tasks: TASK + SHAPE + GUARD (skip PRIME/FOCUS/ACTIVATE)
- Analysis tasks: full LAP (all layers active)
- Design tasks: Seed Graph Notation instead

**Status:** Proposed. Not yet experimentally tested as a complete protocol.

### Relationship Between Concepts

```
TOON ──evolved──→ Seed Pattern ──generalized──→ LAP
                                                 │
Seed Graph ──informs──→ LAP (FOCUS, ANCHOR)      │
                                                 │
Experiment data ──validates──→ LAP layers:        │
  TOON @! constraints ≈ ACTIVATE layer    ◄──────┘
  Markdown freedom ≈ minimal SUPPRESS
  Seed TRANSITIONS ≈ ANCHOR layer
  Prose "Reply with code" ≈ NL TASK layer
```

---

## Experiment Timeline

### Experiment 01: TOON to Gemini (cross-model format test)
- **Method:** Sent TOON brief to Gemini 2.5 Flash via API
- **Cold (no hint):** Gemini read TOON perfectly, responded in prose+code. Understood as input, didn't mirror format.
- **With hint ("communicate in @-sigil notation"):** Gemini replied IN @-sigil format AND invented new sigils (@R, @alg, @justification).
- **Finding:** Models can read and produce novel notation cross-architecture. Format comprehension is universal. Format production requires a hint.

### Experiment 02: Three encodings for same task
- **Method:** Sent "add Zod schema" task to Gemini in 3 formats
- **Results:**

| Encoding | Correct | Tokens in | Tokens out |
|----------|---------|-----------|------------|
| Prose | 5/5 | ~60 | ~50 |
| Test-as-spec | 3/5 | ~120 | ~30 |
| Minimal code | 3/5 | ~70 | ~80 |

- **Finding:** Prose won. Implicit constraints (hidden in test assertions) were not fully traced. Explicit constraints outperform implicit ones.

### Experiment 03: 3-model design conversation
- **Method:** Claude seeded a graph notation → Gemini extended → DeepSeek extended + challenged
- **Results:** All three models continued the notation without instruction. DeepSeek invented `CHALLENGED_EDGES:`.
- **Finding:** Seed patterns work cross-architecture. The format EMERGES rather than being imposed.

### Experiment 04: Full matrix (36 calls)
- **Method:** 3 tasks × 3 formats × 4 models (Codex CLI, Gemini CLI, Sonnet 4.6, GPT-4.1)
- **Grading:** 3 independent Opus agents evaluating comprehension, fidelity, completeness, quality

**Results by task × format (avg /12 across 4 models):**

| Task | Markdown | Seed | TOON | Winner |
|------|:---:|:---:|:---:|--------|
| Simple (code gen) | **11.75** | 11.50 | 10.75 | Markdown |
| Medium (state machine) | **11.25** | 9.50 | 7.75* | Markdown |
| Complex (analysis) | 10.75 | 10.25 | **11.50** | TOON |

*TOON medium includes Codex timeout (0/12). Excluding Codex: 10.33

**Results by model (all formats, all tasks, /108):**

| Model | Score |
|-------|:---:|
| Sonnet 4.6 | 99 |
| GPT-4.1 | 95 |
| Gemini CLI | 95 |
| Codex CLI | 91 |

**Input token cost:**

| Format | Avg tokens | vs Markdown |
|--------|:---:|:---:|
| Seed | 138 | -15% (cheapest) |
| Markdown | 163 | baseline |
| TOON | 201 | +23% (most expensive) |

**Key findings:**

1. **Format effectiveness is task-dependent.** Code → Markdown. Analysis → TOON. This overturned the earlier "format doesn't matter" conclusion from Experiment 03.

2. **TOON constraints act as weight activators.** `@! must::explain_mechanism` pushed GPT-4.1 from 10/12 to 12/12 on analysis. It activated deeper reasoning, not just instruction-following.

3. **TOON's output constraint failed.** `@? {code}` was less effective than plain English "Reply with just the code." Formal syntax triggers over-explanation in instruction-tuned models.

4. **Markdown gives engineering freedom models USE.** Codex invented socket identity tracking, Gemini invented copy-before-iterate — only in markdown, never in TOON/seed. Constrained formats suppress emergent engineering patterns.

5. **Codex CLI chokes on TOON.** 3-8x slower, medium task timed out at 180s.

6. **Sonnet 4.6 is format-resilient.** 10-12 across every format and task.

7. **Comprehension was 3/3 across the board.** Format never blocked understanding. It affected quality and behaviour, not comprehension.

---

## Prior Art

Research conducted via Perplexity Deep Research, 2026-04-11.

### Directly relevant

| Work | Key finding | Relevance to LAP |
|------|-------------|-------------------|
| **Interlat** [arxiv 2511.09149] | Direct latent-space LLM-to-LLM communication achieves 24x latency reduction. Compressed to 8 tokens while maintaining performance. | The theoretical ceiling. LAP approximates this with tokens since we can't transmit hidden states via bash pipes. |
| **Priming theory** [keyann.dev/posts/priming-the-context-window] | "Spreading activation in embedding space" — word placement biases model interpretation beyond instruction-following. | Mechanistic basis for PRIME and ROLE layers. |
| **Sparse Autoencoders** [arxiv 2309.08600] | Models encode info using sparsely activating features. Different prompts activate different feature regions. | Mechanistic basis for why domain anchors (PRIME) work. |
| **Persona steering vectors** [arxiv 2601.02896] | SAE latents discover NL prompts that steer behaviour by "neutralising rather than shifting." | This IS the SUPPRESS layer — neutralise unhelpful defaults rather than adding new behaviour. |
| **DisCIPL** [MIT, news.mit.edu] | Orchestrator decomposes tasks for smaller "follower" models via explicit constraints. Achieves o1-level performance with small models. 40% shorter reasoning, 80% cost savings. | Foreman's pit-boss/worker pattern validated independently. Constraint delegation to smaller models works. |
| **Format effects** [arxiv 2411.10541] | Prompt format variations yield up to 40% performance differences. GPT-3.5 sensitive, GPT-4 more robust. | Confirmed task-dependent. Smaller models benefit more from format optimisation. |

### Ecosystem context

| Work | Relevance |
|------|-----------|
| **A2A Protocol** (Google, 50+ partners) | Standardised agent-to-agent communication. JSON-RPC based, capability discovery, task lifecycle. Enterprise-focused, not latent-optimised. |
| **MCP** (Anthropic) | Agent-to-tool integration standard. Foreman already uses this. Complementary to LAP (LAP would sit inside MCP tool parameters). |
| **ThinkTank framework** [arxiv 2506.02931] | Multi-agent with domain experts, coordinator, critical thinker. Similar to Foreman's pit-boss/design-partner/implementor. |
| **Anthropic Research System** [anthropic.com/engineering] | Lead agent + parallel subagents. 90.2% improvement over single-agent Opus. Validates orchestrator-worker pattern. |

### Theoretical foundation

| Concept | Implication for LAP |
|---------|---------------------|
| **Latent space theory** [arxiv 2304.09960] | Emergent abilities (ICL, CoT) arise from Bayesian inference over sparse latent distributions. Prompts are queries that activate pre-existing structure. LAP's layers are targeted queries. |
| **Attention head specialisation** [emergentmind.com] | Different heads specialise for syntax, position, delimiters. Structured formats may activate different heads than prose. Explains task-dependent format effects. |
| **Constrained decoding** [aidancooper.co.uk] | Format compliance can be guaranteed by constraining token generation. Not applicable via API, but relevant for local model deployment. |

---

## Architecture Council Verdict

Council: Codex (GPT-5.4), Gemini (3 Pro), Claude Opus (Moderator).
Session: 2026-04-11.

### Gemini 3 Pro: ADOPT (HIGH confidence)

- LAP is sound because it moves from "Prompt as Protocol" to "Prompt as Latent Space Activation"
- Evidence directly proves ACTIVATE/SUPPRESS layers (TOON analysis data)
- Must be implemented as **dynamic orchestration matrix**, not static template
- Risk: cognitive overload if all layers populated for every task
- LAP subsumes Markdown — a plain brief is just LAP with only TASK layer active

### Codex (GPT-5.4): ADOPT AS HEURISTIC (0.78 confidence)

- Evidence supports task-sensitive layers, NOT an 8-layer mandatory envelope
- PRIME, ROLE, FOCUS, TASK, SHAPE are reasonable
- ACTIVATE proven only for `explain_mechanism`; SUPPRESS unproven by this dataset
- ANCHOR carries bias risk (example may overconstrain worker)
- 36 calls is directional, not definitive — need more ablation data
- Recommends "LAP-lite": task-specific dispatch rules, not a universal protocol

### Moderator (Opus): ADOPT LAP-LITE, GRADUATE TO FULL WITH ABLATION DATA

- Both advisors agree on direction, disagree on scope
- SUPPRESS needs independent testing (not yet ablated)
- Codex's "lightweight heuristic" is the right starting point
- Full LAP is the right experimental target for validation
- Ship heuristic for production, run full LAP for research

### Council consensus

| Decision | Agreed |
|----------|--------|
| Task-dependent format selection | Yes (all 3) |
| LAP layers must NOT be mandatory per task | Yes (all 3) |
| Natural language > symbolic syntax for TASK/SHAPE | Yes (all 3) |
| Code tasks need freedom, analysis needs constraints | Yes (all 3) |
| Full LAP should be tested experimentally | Yes (Gemini + Moderator; Codex abstains on priority) |

---

## Conclusions

### What we proved

1. **LLMs communicate via shared training priors.** Three model families continued a novel notation from a single seed example. No format spec needed.

2. **Format affects quality, not comprehension.** 34/36 tests showed 3/3 comprehension regardless of format. But quality varied by up to 2 points depending on format × task interaction.

3. **Activation > instruction for reasoning tasks.** TOON's `@! must::explain_mechanism` activated deeper analysis in GPT-4.1 and Codex. It wasn't an instruction they followed — it was a capability they turned on.

4. **Freedom > structure for engineering tasks.** Markdown outperformed structured formats for code because models invent engineering patterns (socket identity tracking, copy-before-iterate) when unconstrained.

5. **Explicit constraints > implicit constraints.** Across all experiments. Tests-as-spec failed because models don't fully trace assertion implications.

### What we hypothesise (untested)

1. **Full LAP (all 8 layers) will outperform markdown on analysis tasks and match it on code tasks** — because the pit-boss can choose which layers to activate.

2. **SUPPRESS independently improves output** — by neutralising defaults like "surface labels" and "it depends" without adding positive instruction.

3. **Layer ablation will reveal 2-3 load-bearing layers** — probably ACTIVATE, FOCUS, and TASK — with the rest being marginal.

4. **LAP will be model-sensitive** — Sonnet 4.6 won't care (format-resilient), but GPT-4.1 and Codex will respond differently to different layer combinations.

---

## Open Questions

1. **Does full LAP outperform per-layer baselines?** Need ablation: full LAP → remove one layer at a time → measure drop.

2. **Is SUPPRESS independently valuable?** Or does it just duplicate ACTIVATE's effect? Need an ACTIVATE-only vs ACTIVATE+SUPPRESS comparison.

3. **Does ANCHOR help or constrain?** The seed pattern evidence says it helps for format, but it might overconstrain code patterns (worker copies the example too literally).

4. **What's the optimal layer set per task type?** The pit-boss needs a decision function: given task type T and model M, which layers to include.

5. **Does LAP work for multi-turn?** Current experiments are single-turn (brief → response). Real Foreman work involves rejection → re-brief → retry. Does LAP help or hurt on re-briefs?

6. **Can LAP be auto-tuned?** Instead of the pit-boss manually selecting layers, could it learn which layers to activate based on unit rejection history?

---

## Files Reference

All experiment data in `foreman-mcp/_DOJO/Comms/`:

| File | Contents |
|------|----------|
| `RESEARCH.md` | This document |
| `TOON-SPEC.md` | Original TOON format specification |
| `toon.ts` | TOON codec (Zod schemas, serialiser, parser) |
| `toon.test.ts` | 28 passing tests for TOON codec |
| `COLD-TEST.md` | Manual cold-test protocol for TOON |
| `experiment-02.md` | Test-as-spec hypothesis and design |
| `experiment-03.py` | Experiment 03 runner (Markdown vs Seed, 4 API models) |
| `experiment-03-results.json` | Raw results from Experiment 03 |
| `experiment-04.py` | Experiment 04 runner (Markdown vs Seed vs TOON, 4 models incl CLIs) |
| `experiment-04-results.json` | Raw results from Experiment 04 |
| `round-trip-full.txt` | 3-model design conversation (Claude → Gemini → DeepSeek) |
| `gemini-cold-response.txt` | Gemini's cold TOON response |
| `gemini-hint-response.txt` | Gemini's hinted @-sigil response |
| `FINDINGS.md` | Experiment 01-03 findings |
| `VERDICT.md` | Experiment 03 verdict |
| `VERDICT-FINAL.md` | Experiment 04 verdict with grading |
