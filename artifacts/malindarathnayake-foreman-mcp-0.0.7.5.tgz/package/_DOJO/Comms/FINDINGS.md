# Findings — LLM-to-LLM Dense Communication

## Experiment Results

### Exp 1: TOON sigils to Gemini
- Cold (no hint): Gemini read TOON perfectly, responded in prose+code. Understood format as INPUT, didn't mirror it.
- With hint: Gemini replied in @-sigil format AND invented new sigils (@R, @alg, @justification). Natural extension.

### Exp 2: Three encodings compared (task: add Zod schema)
| Encoding       | Correct? | Tokens in | Tokens out |
|----------------|----------|-----------|------------|
| Test-as-spec   | 3/5      | ~120      | ~30        |
| Prose           | 5/5      | ~60       | ~50        |
| Minimal code   | 3/5      | ~70       | ~80        |

Prose won. Test-as-spec failed because implicit constraints (in assertions) were not fully traced by the model. Minimal confused the model into hallucinating context.

### Exp 3: 3-model round-trip design conversation
Claude (seed) -> Gemini (extend) -> DeepSeek R1 (extend + challenge)

| Turn       | Model            | Tokens | Nodes added | OPEN resolved |
|------------|------------------|--------|-------------|---------------|
| 1 (seed)   | Claude Opus      | ~289   | 5           | (started 4)   |
| 2 (extend) | Gemini 2.5 Flash | ~632   | +7          | 4/4, opened 4 |
| 3 (extend) | DeepSeek R1      | ~920   | +7          | 4/4, opened 3 |

**All three models used the same notation without being told how.**

## Core Discovery

### The format doesn't matter. The seed pattern does.

I seeded with `DIMS: [...] NODES: {...} EDGES: {...} OPEN: {...}`.
Gemini continued it exactly. DeepSeek continued it AND added
`CHALLENGED_EDGES:` (invented a new section type).

No model asked "what format is this?" No model broke the pattern.
The shared training prior for graph/dict notation is deep enough
that any model picks it up from a single example.

### Implications for Foreman

TOON was solving the wrong problem. It was a rigid format spec for
something that doesn't need a format spec. What it needs is:

1. **A seed pattern** — the first message establishes the shape
2. **Code as payload** — both models understand code natively
3. **Explicit constraints** — implicit (test-based) constraints underperform
4. **Minimal routing** — file + anchor + operation, nothing more

The pit-boss doesn't need a serializer/parser. It needs to START
the conversation in a shape that the worker naturally continues.

### What TOON got right
- Dimensions as explicit structure (DIMS/axes)
- Code payload as the primary content
- Constraints as separate concern from payload
- Verification as a declared field

### What TOON got wrong
- Rigid sigil format (models don't need it)
- Human-readable design (models don't care)
- Formal parser (models ARE the parser)
- Fixed vocabulary (models naturally extend notation)

## The Protocol (evolved)

Not a format. A seed + convention:

### For code tasks (pit-boss -> worker):
```
TARGET: <file>
AFTER: <anchor>
OP: insert
---
<code payload>
---
GUARD: <what not to touch>
TEST: <verify command>
REPLY: <expected shape>
```

### For design tasks (model <-> model):
```
TOPIC: <what>
DIMS: [<dimensions>]
NODES: {<graph>}
EDGES: {<relationships>}
OPEN: {<questions>}
```

The receiver extends naturally. No format spec needed.

### For review tasks:
```
FILE: <path>
RANGE: <lines or anchor>
FINDING: <what's wrong>
SEVERITY: <level>
FIX: <proposed or OPEN>
```

Each task type gets the encoding native to it.
The models figure out the rest.

## Next Steps

1. Test the seed pattern in a real Foreman worker dispatch
   - Pit-boss sends minimal seed brief to Sonnet worker
   - Compare output quality vs current prose briefs
   - Measure token savings

2. Test the design conversation pattern for Foreman design-partner
   - Replace prose-heavy design session with graph notation
   - See if YIELD checkpoints still work

3. Explore: can a 3rd model implement from a 2-model conversation?
   - Feed the round-trip graph to Codex/Sonnet
   - Ask it to implement what was designed
   - Tests whether the graph captures enough intent

## Open Questions

1. Verbosity control: models keep expanding the graph. How to
   constrain? Token budget in the prompt? Explicit "max N nodes"?

2. Convergence: the 3-model conversation DIVERGED (more OPEN items
   each turn). How to drive toward CLOSURE?

3. Fidelity: does the graph preserve enough info for implementation?
   Or does it lose the nuance that prose carries?
