/**
 * TOON — Terse Operation-Oriented Notation
 *
 * Standalone PoC — no Foreman imports.  This file is the codec:
 *   ToonBriefSchema  — Zod schema (validates the typed object)
 *   serializeToon()  — ToonBrief → UTF-8 string (pit-boss writes)
 *   parseToon()      — UTF-8 string → ToonBrief (validation/logging)
 *   estimateTokens() — rough token count for A/B comparison
 *
 * The worker never calls parseToon() — it reads the text directly and
 * its training priors do the "parsing".
 */

import { z } from "zod"

// ─── Schemas ──────────────────────────────────────────────────────────────────

export const ToonOpType = z.enum(["insert", "replace", "delete", "create"])

export const ToonRelation = z.enum([
  "after",    // insert after anchor
  "before",   // insert before anchor
  "replace",  // replace the anchor itself
  "inside",   // insert inside anchor's body
  "eof",      // end of file
  "bof",      // beginning of file
])

export const ToonConstraintKind = z.enum([
  "must_not",  // hard — violation = rejection
  "must",      // required — absence = rejection
  "prefer",    // soft — violation = warning
])

export const ToonOpSchema = z.object({
  id:      z.string().max(8),
  op:      ToonOpType,
  target:  z.object({
    file:    z.string().max(500),
    anchor:  z.string().max(200),
    rel:     ToonRelation,
  }),
  payload: z.string().max(10000).optional(),
  deps:    z.array(z.string().max(8)).default([]),
})

export const ToonConstraintSchema = z.object({
  kind:  ToonConstraintKind,
  scope: z.string().max(200),
  rule:  z.string().max(500),
})

export const ToonEvidenceSchema = z.object({
  label: z.string().max(100),
  code:  z.string().max(2000),
})

export const ToonBriefSchema = z.object({
  v:           z.literal(1),
  frame:       z.object({
    anchors:   z.array(z.string().max(50)).min(2).max(8),
    scope:     z.array(z.string().max(500)).min(1),
    axes:      z.array(z.string().max(30)).min(1).max(8),
  }),
  ops:         z.array(ToonOpSchema).min(1).max(30),
  constraints: z.array(ToonConstraintSchema).max(15).default([]),
  verify:      z.object({
    cmd:       z.string().max(500),
    expect:    z.record(z.unknown()),
  }),
  sigma:       z.number().min(0).max(1),
  gloss:       z.string().max(500).optional(),
  context:     z.string().max(1000).optional(),
  evidence:    z.array(ToonEvidenceSchema).max(5).optional(),
})

// ─── Types ────────────────────────────────────────────────────────────────────

export type ToonBrief      = z.infer<typeof ToonBriefSchema>
export type ToonOp         = z.infer<typeof ToonOpSchema>
export type ToonConstraint = z.infer<typeof ToonConstraintSchema>
export type ToonEvidence   = z.infer<typeof ToonEvidenceSchema>

// ─── Serialiser ───────────────────────────────────────────────────────────────
// ToonBrief → UTF-8 string.  The pit-boss calls this.

export function serializeToon(brief: ToonBrief): string {
  const b = ToonBriefSchema.parse(brief)
  const out: string[] = []
  const primary = b.frame.scope[0]

  // header + frame
  out.push("#TOON/1")
  out.push(`@F ${b.frame.anchors.join("|")}`)
  out.push(`@S ${b.frame.scope.join(" ")}`)
  out.push(`@A ${b.frame.axes.join("|")}`)

  // operations
  for (const op of b.ops) {
    out.push("")
    const deps = op.deps.length ? `  deps=${op.deps.join(",")}` : ""
    out.push(`@Δ${op.id} ${op.op}::${op.target.anchor}+${op.target.rel}${deps}`)
    if (op.target.file !== primary) {
      out.push(`  file=${op.target.file}`)
    }
    if (op.payload) {
      for (const line of op.payload.split("\n")) {
        out.push(`  ${line}`)
      }
    }
  }

  // constraints
  if (b.constraints.length) {
    out.push("")
    for (const c of b.constraints) {
      out.push(`@! ${c.kind}::${c.scope} ${c.rule}`)
    }
  }

  // evidence
  if (b.evidence?.length) {
    out.push("")
    for (const e of b.evidence) {
      out.push(`@E ${e.label}::`)
      for (const line of e.code.split("\n")) {
        out.push(`  ${line}`)
      }
    }
  }

  // context
  if (b.context) {
    out.push("")
    out.push(`@C ${b.context}`)
  }

  // verification + metadata
  out.push("")
  out.push(`@T ${b.verify.cmd}`)
  out.push(`@? ${JSON.stringify(b.verify.expect)}`)
  out.push(`@σ ${b.sigma}`)

  if (b.gloss) {
    out.push(`@~ ${b.gloss}`)
  }

  return out.join("\n")
}

// ─── Parser ───────────────────────────────────────────────────────────────────
// UTF-8 string → ToonBrief.  Line-by-line state machine.
// Used for validation & logging, NOT by the worker.

interface PendingOp {
  id: string
  op: ToonOp["op"]
  file: string
  anchor: string
  rel: ToonOp["target"]["rel"]
  deps: string[]
  payload: string[]
}

export function parseToon(text: string): ToonBrief {
  const lines = text.split("\n")

  let anchors: string[] = []
  let scope: string[] = []
  let axes: string[] = []
  const ops: ToonOp[] = []
  const constraints: ToonConstraint[] = []
  const evidence: ToonEvidence[] = []
  let context: string | undefined
  let verifyCmd = ""
  let verifyExpect: Record<string, unknown> = {}
  let sigma = 0.5
  let gloss: string | undefined

  let pendingOp: PendingOp | null = null
  let pendingEv: { label: string; lines: string[] } | null = null

  function flushOp() {
    if (!pendingOp) return
    const p = pendingOp
    ops.push({
      id: p.id,
      op: p.op,
      target: { file: p.file, anchor: p.anchor, rel: p.rel },
      payload: p.payload.length ? p.payload.join("\n") : undefined,
      deps: p.deps,
    })
    pendingOp = null
  }

  function flushEv() {
    if (!pendingEv) return
    evidence.push({ label: pendingEv.label, code: pendingEv.lines.join("\n") })
    pendingEv = null
  }

  function flushAll() { flushOp(); flushEv() }

  for (const raw of lines) {
    const trimmed = raw.trim()

    // blank / header
    if (trimmed === "" || trimmed.startsWith("#TOON/")) continue

    // indented content → belongs to current block
    if (raw.startsWith("  ") && !trimmed.startsWith("@")) {
      const content = raw.slice(2)
      if (pendingOp) {
        if (content.startsWith("file=")) {
          pendingOp.file = content.slice(5).trim()
        } else {
          pendingOp.payload.push(content)
        }
      } else if (pendingEv) {
        pendingEv.lines.push(content)
      }
      continue
    }

    // ─── sigil dispatch ─────────────────────────────────────────────

    if (trimmed.startsWith("@F ")) {
      flushAll()
      anchors = trimmed.slice(3).split("|").map(s => s.trim())
    }
    else if (trimmed.startsWith("@S ")) {
      flushAll()
      scope = trimmed.slice(3).split(/\s+/).map(s => s.trim())
    }
    else if (trimmed.startsWith("@A ")) {
      flushAll()
      axes = trimmed.slice(3).split("|").map(s => s.trim())
    }
    else if (trimmed.startsWith("@Δ")) {
      flushAll()
      // @Δa insert::AnchorName+after  deps=b,c
      const m = trimmed.match(/^@Δ(\S+)\s+(\w+)::(.+?)\+(\w+)(?:\s+deps=(\S+))?$/)
      if (m) {
        pendingOp = {
          id: m[1],
          op: m[2] as ToonOp["op"],
          anchor: m[3],
          rel: m[4] as ToonOp["target"]["rel"],
          file: scope[0] ?? "",
          deps: m[5] ? m[5].split(",").map(s => s.trim()) : [],
          payload: [],
        }
      }
    }
    else if (trimmed.startsWith("@! ")) {
      flushAll()
      const m = trimmed.match(/^@!\s+(must_not|must|prefer)::(\S+)\s+(.+)$/)
      if (m) {
        constraints.push({ kind: m[1] as ToonConstraint["kind"], scope: m[2], rule: m[3] })
      }
    }
    else if (trimmed.startsWith("@E ")) {
      flushAll()
      pendingEv = { label: trimmed.slice(3).replace(/::$/, "").trim(), lines: [] }
    }
    else if (trimmed.startsWith("@C ")) {
      flushAll()
      context = trimmed.slice(3)
    }
    else if (trimmed.startsWith("@T ")) {
      flushAll()
      verifyCmd = trimmed.slice(3)
    }
    else if (trimmed.startsWith("@? ")) {
      try { verifyExpect = JSON.parse(trimmed.slice(3)) }
      catch { verifyExpect = { raw: trimmed.slice(3) } }
    }
    else if (trimmed.startsWith("@σ ")) {
      sigma = parseFloat(trimmed.slice(3))
    }
    else if (trimmed.startsWith("@~ ")) {
      gloss = trimmed.slice(3)
    }
  }

  flushAll()

  return ToonBriefSchema.parse({
    v: 1,
    frame: { anchors, scope, axes },
    ops,
    constraints,
    verify: { cmd: verifyCmd, expect: verifyExpect },
    sigma,
    gloss,
    context,
    evidence: evidence.length ? evidence : undefined,
  })
}

// ─── Token Estimation ─────────────────────────────────────────────────────────
// ~4 chars/token for code-heavy text (Claude tokeniser heuristic).
// Good enough for A/B comparison, not for billing.

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4)
}
