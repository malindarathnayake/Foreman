# Final Verdict — LLM-to-LLM Communication Experiments

## Experiment 04: Full Matrix

**36 calls**: 3 tasks × 3 formats × 4 models (Codex CLI, Gemini CLI, Sonnet 4.6, GPT-4.1)
**Graded by**: 3 independent Opus agents evaluating input/output fidelity

## Scores by Task × Format (avg /12 across 4 models)

| Task | Markdown | Seed | TOON | Winner |
|------|:---:|:---:|:---:|--------|
| Simple (code gen) | **11.75** | 11.50 | 10.75 | Markdown |
| Medium (state machine) | **11.25** | 9.50 | 7.75* | Markdown |
| Complex (analysis) | 10.75 | 10.25 | **11.50** | TOON |

*TOON medium dragged down by Codex CLI timeout (0/12). Excluding Codex: TOON medium = 10.33

## Scores by Model (all formats, all tasks, /108)

| Model | Score | Best format |
|-------|:---:|-------------|
| Sonnet 4.6 | 99 | Format-independent (10-12 across all) |
| GPT-4.1 | 95 | Markdown for code, TOON for analysis |
| Gemini CLI | 95 | Markdown (12/12 on medium) |
| Codex CLI | 91 | Markdown (12/12 on medium, but TOON timeout) |

## The Core Finding

### Format effectiveness is task-dependent.

```
CODE GENERATION  →  Markdown wins
                    (freedom to apply engineering judgment)

IMPLEMENTATION   →  Markdown wins
                    (room for architecture decisions)

ANALYSIS         →  TOON wins
                    (explicit constraints force mechanism depth)
```

This was NOT the finding from experiment 03 (which concluded "format doesn't matter").
The fidelity-based grading methodology revealed format effects that raw quality
scoring missed.

## Input Token Cost

| Task | Markdown | Seed | TOON |
|------|:---:|:---:|:---:|
| Simple | 100 | **88** (-12%) | 131 (+31%) |
| Medium | 216 | **197** (-9%) | 290 (+34%) |
| Complex | 172 | **130** (-24%) | 182 (+6%) |
| **Average** | **163** | **138** (-15%) | **201** (+23%) |

Seed is the cheapest format. TOON is the most EXPENSIVE — more than markdown.
The @! constraint lines add overhead that exceeds any compression from sigils.

## Key Insights

### 1. TOON constraints work for REASONING, not CODE

The `@! must::explain_mechanism(... not_just_label)` constraint measurably
pushed models past surface-level labeling:

- GPT-4.1: markdown=10, TOON=12 on complex (timing diagram + boundary fix)
- Codex-CLI: markdown=11, TOON=12 on complex (separated "enforcement scope vs quota scope")
- Gemini-CLI: markdown=10, TOON=10 on complex (step-by-step timing added)

But for code tasks, TOON's formality triggered over-explanation:
- GPT-4.1 and Sonnet-4.6 both appended unwanted prose to TOON code responses
- The `@? {code}` directive was LESS effective than "Reply with just the code"

### 2. Codex CLI chokes on TOON

| Task | Codex+Markdown | Codex+Seed | Codex+TOON |
|------|:-:|:-:|:-:|
| Simple | 41s | **20s** | 168s |
| Medium | 54s | 55s | **TIMEOUT** |
| Complex | 35s | **28s** | 52s |

Codex processes seed fastest, markdown second, TOON worst. The @-sigil
notation causes Codex to deliberate excessively. For the medium task's
complex TOON (290 input tokens with 13 @! constraints), it exceeded 180s.

### 3. Markdown gives models engineering freedom they USE well

Codex-CLI+markdown produced socket identity tracking (prevents stale callbacks).
Gemini-CLI+markdown produced copy-before-iterate in EventEmitter (prevents
mutation bugs). Neither model invented these patterns in TOON or seed —
the constrained formats focused them on checking boxes rather than engineering.

### 4. Seed is the safe middle ground

Seed never won a category outright but never catastrophically failed either.
It's the cheapest format (-15% input tokens) and works across all models
and CLI tools. For Foreman's pit-boss-to-worker briefs, seed is the
pragmatic default.

### 5. Sonnet 4.6 is the most format-resilient model

Sonnet 4.6 scored 10-12 across EVERY format and task. It treated seed
structure as architectural blueprints, followed TOON constraints, and
used markdown freedom well. The format choice matters least for the
most capable model.

## What This Means for Foreman

### Use format as a tool, not a standard.

The pit-boss should select format based on task type:

| Pit-boss sending to worker for... | Use... | Why... |
|-----------------------------------|--------|--------|
| Code implementation | **Markdown or Seed** | Models need freedom for engineering judgment |
| Code review / analysis | **TOON-style constraints** | Explicit @! forces depth over labels |
| Design deliberation | **Seed graph notation** | Models extend it naturally (proven in exp 03) |
| Quick bug fix | **Minimal** (just the code) | No envelope overhead needed |

### Don't use TOON for Codex CLI dispatches.

Codex is 3-8x slower with TOON and can timeout. Use seed or markdown.

### The "shared manifold" hypothesis is confirmed for comprehension, irrelevant for quality.

All models, in all formats, scored 3/3 on comprehension in 34/36 cases.
The format never blocked understanding. But quality depends on whether
the format gives the model room to think (code tasks) or forces it to
be rigorous (analysis tasks). These are opposite pressures.

## Experiment Cost

- OpenRouter API: ~$3.50 (18 calls across Sonnet 4.6 + GPT-4.1)
- Gemini CLI: free tier
- Codex CLI: ~$1.50 (9 calls)
- Analysis agents: ~$2.00 (3 Opus agents × ~50K tokens each)
- **Total: ~$7.00**

## Files in _DOJO/Comms/

```
TOON-SPEC.md              — Original TOON format spec (historical)
toon.ts                   — TOON codec (Zod schemas, serializer, parser)
toon.test.ts              — 28 passing tests for the codec
COLD-TEST.md              — Manual test protocol
experiment-02.md          — Test-as-spec hypothesis
experiment-03.py          — Experiment 03: Markdown vs Seed (4 models)
experiment-03-results.json
experiment-04.py          — Experiment 04: Markdown vs Seed vs TOON (4 models incl CLIs)
experiment-04-results.json
round-trip-full.txt       — 3-model design conversation (Claude→Gemini→DeepSeek)
gemini-cold-response.txt  — Gemini's raw TOON response
gemini-hint-response.txt  — Gemini's @-sigil response with hint
FINDINGS.md               — Experiment 01-03 findings
VERDICT.md                — Experiment 03 verdict
VERDICT-FINAL.md          — This file
```
