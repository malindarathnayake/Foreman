# Cold Test Protocol

The real validation: hand a TOON brief to Sonnet **with no preamble,
no explanation of the format** and see if it produces correct code.

If yes → the format's shared-prior hypothesis holds.
If no → we learn where anchors need tuning or `@~` gloss becomes mandatory.

## Test Matrix

| Test | Preamble | @~ Gloss | Expected result |
|------|----------|----------|-----------------|
| A    | None     | None     | Sonnet follows ops cold |
| B    | None     | Present  | Sonnet uses gloss as fallback |
| C    | 1-line   | None     | "This is a TOON brief — a dense task encoding." |
| D    | None     | None     | Complex multi-file brief |

## Test A — Raw TOON, No Preamble, No Gloss

Feed this EXACT text as the full worker prompt (nothing else):

```
#TOON/1
@F zod|vitest|typescript|named-export
@S foreman-mcp/src/types.ts
@A structure|type-safety

@Δa insert::ReadLedgerInputSchema+after
  export const TestColdSchema = z.object({
    name: z.string().max(100),
    value: z.number().min(0),
  })

@Δb insert::TestColdSchema+after  deps=a
  export type TestColdInput = z.infer<typeof TestColdSchema>

@! must_not::modify(ReadLedgerInputSchema|WriteLedgerInputSchema)
@! must::named_export(TestColdSchema)

@E pattern::
  export const ReadLedgerInputSchema = z.object({...})
  export type ReadLedgerInput = z.infer<typeof ReadLedgerInputSchema>

@T cd foreman-mcp && npx vitest run tests/writeTools.test.ts
@? {"files":"string[]","pass":"bool"}
@σ 0.9
```

### Evaluation Criteria

1. Did it add code after `ReadLedgerInputSchema`? (anchor comprehension)
2. Did it create `TestColdSchema` with correct shape? (payload fidelity)
3. Did it add the type export after the schema? (dep ordering)
4. Did it modify existing schemas? (constraint adherence)
5. Did it run the test command? (verification awareness)

### Scoring

- 5/5 = TOON works cold, no gloss needed
- 4/5 = Minor issue, one sigil misread
- 3/5 = Gloss needed (@~), core concept understood
- 2/5 = Major misread, format not intuitive
- 1/5 = Format rejected, falls back to asking for clarification

## Test B — Raw TOON With Gloss

Same as Test A but append:

```
@~ Add a Zod schema called TestColdSchema after ReadLedgerInputSchema in types.ts. Export both schema and inferred type.
```

Compare output quality with Test A.

## Test C — Minimal Preamble

Prepend exactly one line before the TOON:

```
This is a TOON brief — a dense task encoding. Each @-sigil is a dimension of the task.
```

Then the same TOON as Test A.

## Test D — Multi-File Cold

```
#TOON/1
@F express|zod-validate|middleware-chain|error-boundary
@S src/routes/users.ts src/middleware/auth.ts
@A request-flow|auth|validation

@Δa insert::authenticateToken+after
  file=src/middleware/auth.ts
  export function requireRole(role: string) {
    return (req: Request, res: Response, next: NextFunction) => {
      if (req.user?.role !== role) return res.status(403).json({ error: "forbidden" })
      next()
    }
  }

@Δb insert::router.get("/users")+after  deps=a
  router.delete("/users/:id", requireRole("admin"), async (req, res) => {
    await deleteUser(req.params.id)
    res.status(204).end()
  })

@! must_not::modify(authenticateToken|router.get)
@! must::requireRole-before-handler
@! prefer::204-no-body-on-delete

@T npm test -- --grep "DELETE /users"
@? {"files":"string[]","pass":"bool"}
@σ 0.8
@~ Add admin-only DELETE /users/:id route. New requireRole middleware in auth.ts, route in users.ts.
```

### Evaluation Criteria (Test D)

1. Did it put `requireRole` in `auth.ts`? (file= comprehension)
2. Did it put the route in `users.ts`? (primary scope)
3. Did it chain `requireRole("admin")` as middleware? (constraint)
4. Did it use 204 no-body? (prefer constraint)
5. Did it avoid modifying existing code? (must_not)

## Running the Tests

These are manual — spawn a Sonnet worker via Claude Code Agent tool
with the raw TOON text as the prompt. Compare output against criteria.

Results go in `COLD-TEST-RESULTS.md` in this directory.
