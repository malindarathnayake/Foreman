import { describe, it, expect } from "vitest"
import {
  ToonBriefSchema,
  serializeToon,
  parseToon,
  estimateTokens,
  type ToonBrief,
} from "./toon.js"

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const SIMPLE_BRIEF: ToonBrief = {
  v: 1,
  frame: {
    anchors: ["zod", "mcp-tool", "named-export", "typescript"],
    scope: ["foreman-mcp/src/types.ts"],
    axes: ["structure", "type-safety", "export"],
  },
  ops: [
    {
      id: "a",
      op: "insert",
      target: {
        file: "foreman-mcp/src/types.ts",
        anchor: "WriteLedgerInputSchema",
        rel: "after",
      },
      payload: [
        "export const NormalizeReviewInputSchema = z.object({",
        "  reviewer: z.string().max(200),",
        "  raw_text: z.string().max(50000),",
        "})",
      ].join("\n"),
      deps: [],
    },
    {
      id: "b",
      op: "insert",
      target: {
        file: "foreman-mcp/src/types.ts",
        anchor: "NormalizeReviewInputSchema",
        rel: "after",
      },
      payload: "export type NormalizeReviewInput = z.infer<typeof NormalizeReviewInputSchema>",
      deps: ["a"],
    },
  ],
  constraints: [
    { kind: "must_not", scope: "modify(WriteLedgerInputSchema|ReadLedgerInputSchema)", rule: "existing schemas are frozen" },
    { kind: "must", scope: "named_export(NormalizeReviewInputSchema)", rule: "consumed by normalizeReview.ts" },
  ],
  verify: {
    cmd: "cd foreman-mcp && npx vitest run tests/writeTools.test.ts",
    expect: { files: "string[]", pass: "bool" },
  },
  sigma: 0.95,
  evidence: [
    {
      label: "existing_pattern",
      code: [
        "export const WriteLedgerInputSchema = z.discriminatedUnion(\"operation\", [...])",
        "export type WriteLedgerInput = z.infer<typeof WriteLedgerInputSchema>",
      ].join("\n"),
    },
  ],
}

const MULTI_FILE_BRIEF: ToonBrief = {
  v: 1,
  frame: {
    anchors: ["express", "middleware", "zod-validate", "error-boundary"],
    scope: ["src/routes/api.ts", "src/middleware/validate.ts", "src/types/api.ts"],
    axes: ["request-flow", "type-safety", "error-handling"],
  },
  ops: [
    {
      id: "a",
      op: "create",
      target: { file: "src/types/api.ts", anchor: "api.ts", rel: "bof" },
      payload: [
        'import { z } from "zod"',
        "export const CreateUserSchema = z.object({",
        "  name: z.string().min(1).max(100),",
        "  email: z.string().email(),",
        '  role: z.enum(["admin", "user"]),',
        "})",
        "export type CreateUserInput = z.infer<typeof CreateUserSchema>",
      ].join("\n"),
      deps: [],
    },
    {
      id: "b",
      op: "insert",
      target: { file: "src/middleware/validate.ts", anchor: "errorHandler", rel: "before" },
      payload: [
        "export function validate(schema: z.ZodSchema) {",
        "  return (req: Request, _res: Response, next: NextFunction) => {",
        "    schema.parse(req.body)",
        "    next()",
        "  }",
        "}",
      ].join("\n"),
      deps: ["a"],
    },
    {
      id: "c",
      op: "insert",
      target: { file: "src/routes/api.ts", anchor: 'router.get("/users")', rel: "before" },
      payload: [
        'router.post("/users", validate(CreateUserSchema), async (req, res) => {',
        "  const input = CreateUserSchema.parse(req.body)",
        "  const user = await createUser(input)",
        "  res.status(201).json(user)",
        "})",
      ].join("\n"),
      deps: ["a", "b"],
    },
  ],
  constraints: [
    { kind: "must_not", scope: "existing-routes", rule: "do not modify or reorder" },
    { kind: "must", scope: "validate-before-handler(CreateUserSchema)", rule: "middleware must precede handler" },
    { kind: "prefer", scope: "early-return-on-error", rule: "let ZodError propagate to boundary" },
  ],
  verify: {
    cmd: 'cd src && npm test -- --grep "POST /users"',
    expect: { files: "string[]", pass: "bool", routes_added: "number" },
  },
  sigma: 0.85,
  context: "Zod parse throws ZodError — existing errorHandler already catches it.",
  gloss: "Add a POST /users route with Zod input validation across three files.",
}

const PROSE_BRIEF = `## Worker Brief — Unit 1a: NormalizeReviewInputSchema

### Context
You are working on the Foreman MCP server, a TypeScript project that
uses Zod for schema validation.  All schemas are defined in
\`foreman-mcp/src/types.ts\`.

### Task
Add a new Zod schema called \`NormalizeReviewInputSchema\` to the types
file.  This schema validates input for the review normalisation tool.

### Location
File: \`foreman-mcp/src/types.ts\`
Add the new schema after the existing \`WriteLedgerInputSchema\`
(around line 86).

### Schema Shape
The schema should have these fields:
- \`reviewer\`: string, max 200 characters
- \`raw_text\`: string, max 50,000 characters

### Requirements
- Export the schema as a named export
- Export the inferred TypeScript type as well
- Follow the same pattern as existing schemas in the file

### DO NOT
- Do not modify any existing schemas
- Do not add any imports that aren't already present
- Do not change the file structure

### Existing Pattern (for reference)
\`\`\`typescript
export const WriteLedgerInputSchema = z.discriminatedUnion("operation", [...])
export type WriteLedgerInput = z.infer<typeof WriteLedgerInputSchema>
\`\`\`

### Testing
Run: \`cd foreman-mcp && npx vitest run tests/writeTools.test.ts\`

### Reply Format
When done, report:
- Files you changed
- Whether tests pass
- Any issues encountered`

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("TOON schema validation", () => {
  it("validates a well-formed simple brief", () => {
    const result = ToonBriefSchema.safeParse(SIMPLE_BRIEF)
    expect(result.success).toBe(true)
  })

  it("validates a well-formed multi-file brief", () => {
    const result = ToonBriefSchema.safeParse(MULTI_FILE_BRIEF)
    expect(result.success).toBe(true)
  })

  it("rejects brief with < 2 anchors", () => {
    const bad = { ...SIMPLE_BRIEF, frame: { ...SIMPLE_BRIEF.frame, anchors: ["zod"] } }
    const result = ToonBriefSchema.safeParse(bad)
    expect(result.success).toBe(false)
  })

  it("rejects brief with no ops", () => {
    const bad = { ...SIMPLE_BRIEF, ops: [] }
    const result = ToonBriefSchema.safeParse(bad)
    expect(result.success).toBe(false)
  })

  it("rejects sigma out of range", () => {
    const bad = { ...SIMPLE_BRIEF, sigma: 1.5 }
    const result = ToonBriefSchema.safeParse(bad)
    expect(result.success).toBe(false)
  })

  it("rejects wrong version", () => {
    const bad = { ...SIMPLE_BRIEF, v: 2 }
    const result = ToonBriefSchema.safeParse(bad)
    expect(result.success).toBe(false)
  })
})

describe("serializeToon", () => {
  it("produces #TOON/1 header", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text.startsWith("#TOON/1")).toBe(true)
  })

  it("encodes frame anchors with pipe separator", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@F zod|mcp-tool|named-export|typescript")
  })

  it("encodes scope as space-separated paths", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    expect(text).toContain("@S src/routes/api.ts src/middleware/validate.ts src/types/api.ts")
  })

  it("encodes axes with pipe separator", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@A structure|type-safety|export")
  })

  it("encodes ops with anchor+rel syntax", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@Δa insert::WriteLedgerInputSchema+after")
    expect(text).toContain("@Δb insert::NormalizeReviewInputSchema+after  deps=a")
  })

  it("adds file= for non-primary scope files", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    // op "a" targets src/types/api.ts but primary scope is src/routes/api.ts
    expect(text).toContain("  file=src/types/api.ts")
  })

  it("omits file= for primary scope file", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    // all ops target the primary scope file — no file= lines
    const fileLines = text.split("\n").filter(l => l.trim().startsWith("file="))
    expect(fileLines).toHaveLength(0)
  })

  it("encodes constraints with kind::scope rule", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@! must_not::modify(WriteLedgerInputSchema|ReadLedgerInputSchema)")
    expect(text).toContain("@! must::named_export(NormalizeReviewInputSchema)")
  })

  it("encodes evidence blocks", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@E existing_pattern::")
    expect(text).toContain("  export const WriteLedgerInputSchema")
  })

  it("encodes context on single line", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    expect(text).toContain("@C Zod parse throws ZodError")
  })

  it("encodes verify + reply + sigma", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).toContain("@T cd foreman-mcp && npx vitest run tests/writeTools.test.ts")
    expect(text).toContain('@? {"files":"string[]","pass":"bool"}')
    expect(text).toContain("@σ 0.95")
  })

  it("encodes gloss when present", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    expect(text).toContain("@~ Add a POST /users route")
  })

  it("omits gloss when absent", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    expect(text).not.toContain("@~")
  })
})

describe("parseToon (round-trip)", () => {
  it("round-trips a simple brief", () => {
    const text = serializeToon(SIMPLE_BRIEF)
    const parsed = parseToon(text)

    expect(parsed.v).toBe(1)
    expect(parsed.frame.anchors).toEqual(SIMPLE_BRIEF.frame.anchors)
    expect(parsed.frame.scope).toEqual(SIMPLE_BRIEF.frame.scope)
    expect(parsed.frame.axes).toEqual(SIMPLE_BRIEF.frame.axes)
    expect(parsed.ops).toHaveLength(2)
    expect(parsed.ops[0].id).toBe("a")
    expect(parsed.ops[0].op).toBe("insert")
    expect(parsed.ops[0].target.anchor).toBe("WriteLedgerInputSchema")
    expect(parsed.ops[0].target.rel).toBe("after")
    expect(parsed.ops[0].deps).toEqual([])
    expect(parsed.ops[1].id).toBe("b")
    expect(parsed.ops[1].deps).toEqual(["a"])
    expect(parsed.constraints).toHaveLength(2)
    expect(parsed.sigma).toBe(0.95)
    expect(parsed.evidence).toHaveLength(1)
  })

  it("round-trips a multi-file brief", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    const parsed = parseToon(text)

    expect(parsed.ops).toHaveLength(3)
    // op "a" should have file override
    expect(parsed.ops[0].target.file).toBe("src/types/api.ts")
    // op "b" should have file override
    expect(parsed.ops[1].target.file).toBe("src/middleware/validate.ts")
    // op "c" should be primary scope file
    expect(parsed.ops[2].target.file).toBe("src/routes/api.ts")
    // dependency chain
    expect(parsed.ops[2].deps).toEqual(["a", "b"])
    // context + gloss preserved
    expect(parsed.context).toContain("ZodError")
    expect(parsed.gloss).toContain("POST /users")
  })

  it("serialize → parse → serialize produces stable output", () => {
    const text1 = serializeToon(SIMPLE_BRIEF)
    const parsed = parseToon(text1)
    const text2 = serializeToon(parsed)
    expect(text2).toBe(text1)
  })

  it("serialize → parse → serialize is stable for multi-file", () => {
    const text1 = serializeToon(MULTI_FILE_BRIEF)
    const parsed = parseToon(text1)
    const text2 = serializeToon(parsed)
    expect(text2).toBe(text1)
  })
})

describe("parseToon (hand-written input)", () => {
  it("parses a minimal hand-written TOON", () => {
    const handWritten = `#TOON/1
@F zod|typescript
@S src/types.ts
@A structure

@Δa insert::Foo+after
  export const Bar = z.object({ x: z.number() })

@T npm test
@? {"pass":"bool"}
@σ 0.8`

    const brief = parseToon(handWritten)
    expect(brief.frame.anchors).toEqual(["zod", "typescript"])
    expect(brief.ops).toHaveLength(1)
    expect(brief.ops[0].payload).toContain("export const Bar")
    expect(brief.sigma).toBe(0.8)
  })
})

describe("token density comparison", () => {
  it("TOON is significantly denser than prose for equivalent brief", () => {
    const toonText = serializeToon(SIMPLE_BRIEF)
    const toonTokens = estimateTokens(toonText)
    const proseTokens = estimateTokens(PROSE_BRIEF)

    // Code payload doesn't compress (it's the same in both formats).
    // The savings come from eliminating framing prose / envelope.
    // 30%+ on concise prose; 50-65% on verbose real-world briefs.
    const savings = 1 - toonTokens / proseTokens
    expect(savings).toBeGreaterThan(0.25)

    // log for visibility when running tests
    console.log("\n── Token Density Comparison ──")
    console.log(`Prose: ${proseTokens} tokens (${PROSE_BRIEF.length} chars)`)
    console.log(`TOON:  ${toonTokens} tokens (${toonText.length} chars)`)
    console.log(`Saving: ${(savings * 100).toFixed(1)}%`)
    console.log(`─────────────────────────────\n`)
  })
})

describe("grep-ability (Linux constraint)", () => {
  it("all dimension sigils are extractable with ^@ prefix", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    const lines = text.split("\n")
    const sigils = lines.filter(l => l.startsWith("@")).map(l => l[1])

    // every sigil line starts with @<char>
    for (const s of sigils) {
      expect(s).toMatch(/[FSAΔ!ECTC?σ~]/)
    }
  })

  it("ops are extractable with grep ^@Δ", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    const opLines = text.split("\n").filter(l => l.startsWith("@Δ"))
    expect(opLines).toHaveLength(3)
  })

  it("constraints are extractable with grep ^@!", () => {
    const text = serializeToon(MULTI_FILE_BRIEF)
    const cLines = text.split("\n").filter(l => l.startsWith("@!"))
    expect(cLines).toHaveLength(3)
  })
})
