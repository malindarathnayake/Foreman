# Design Summary — LAP Experiment

## Problem

We hypothesise that LLM-to-LLM communication can be improved by separating
activation (targeting specific weights/capabilities in the receiver) from
instruction (the task) from shaping (the output format). We call this the
Layered Activation Protocol (LAP). Prior experiments (36 calls, 3 formats,
4 models) showed format effectiveness is task-dependent and that explicit
constraints act as weight activators. LAP has never been tested as a
complete protocol. We need empirical data.

## Approach

Run a controlled experiment: full LAP briefs across 7 diverse model
architectures and 3 task types of varying complexity. Then ablate one
layer at a time to identify which layers are load-bearing. Compare all
results against existing markdown baselines. Grade with Opus agents on
5 axes.

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Tasks | Same 3 from exp 04 | Direct comparison to 36 existing graded baselines |
| Models | 7 across 5 architectures | Dense, MoE, Western, non-Western, CLI+API |
| Ablation | Full: all removable layers × all tasks × all models | Complete data, no guessing |
| Success criteria | LAP beats best-format-per-task from exp 04 | Markdown 11.75 (code), TOON 11.50 (analysis) |
| Grading | 5 axes: +activation depth | New axis measures what LAP claims to improve |
| Scope | Pure research — no integration concerns | Prove the science, integrate later |

## The 8 LAP Layers

| # | Layer | Purpose | Mechanism |
|---|-------|---------|-----------|
| 1 | PRIME | Narrow knowledge domain | Rare anchor terms activate specific manifolds |
| 2 | ROLE | Set behavioural mode | System-prompt-like priming |
| 3 | FOCUS | Direct dimensional attention | Named axes to reason about |
| 4 | ACTIVATE | Turn UP capabilities | Explicit capability targeting |
| 5 | SUPPRESS | Turn DOWN defaults | Negation boundaries |
| 6 | ANCHOR | Pattern induction | Concrete example to reason from |
| 7 | TASK | The instruction | Natural language (proven most effective) |
| 8 | SHAPE | Output constraints | What the response should look like |

TASK and SHAPE are always present (they're the payload).
Layers 1-6 are the activation envelope — these get ablated.

## Models

| Model | ID | Architecture | Why |
|-------|-----|-------------|-----|
| Sonnet 4.6 | anthropic/claude-sonnet-4.6 | Claude dense (mid) | Baseline worker model |
| Opus 4.6 | anthropic/claude-opus-4.6 | Claude dense (large) | Large model response |
| GPT-5.4 | openai/gpt-5.4 | OpenAI dense (large) | Different architecture |
| Gemini CLI | gemini-3-pro-preview | Google (CLI pipe) | Real transport constraint |
| Gemini 3.1 Pro | google/gemini-3.1-pro-preview | Google (latest) | Newest architecture |
| Kimi K2.5 | moonshotai/kimi-k2.5 | Moonshot dense | Non-Western training data |
| Nemotron 3 Super | nvidia/nemotron-3-super-120b-a12b | Nvidia MoE 120B/12B | Sparse activation |

## Tasks (Same as Experiment 04)

| Task | Type | Complexity | What it tests |
|------|------|-----------|---------------|
| Debounce function | Code generation | Simple | Does LAP help or constrain code tasks? |
| WebSocket reconnection | Implementation | Medium | State machine + engineering judgment |
| Distributed rate limiting | Analysis | Complex | Root cause tracing + mechanism depth |

## Experiment Phases

### Phase 0: Markdown Baselines for New Models
5 new models × 3 tasks × markdown format = **15 calls**
(Sonnet 4.6 and Gemini CLI baselines exist from exp 04)

### Phase 1: Full LAP Baseline
7 models × 3 tasks × full 8-layer LAP = **21 calls**

### Phase 2: Ablation
Remove one layer at a time, keep all others:
7 models × 3 tasks × 6 ablation variants = **126 calls**

| Variant | Removed layer | What it isolates |
|---------|--------------|-----------------|
| LAP−PRIME | PRIME | Do domain anchors help? |
| LAP−ROLE | ROLE | Does behavioural priming help? |
| LAP−FOCUS | FOCUS | Do named dimensions help? |
| LAP−ACTIVATE | ACTIVATE | Do capability targets help? |
| LAP−SUPPRESS | SUPPRESS | Does default suppression help? |
| LAP−ANCHOR | ANCHOR | Does the concrete example help? |

### Phase 3: Grading
3 Opus agents grade all responses on 5 axes (0-3 each, /15 total):

| Axis | What it measures |
|------|-----------------|
| Comprehension | Did the model understand the intent? |
| Fidelity | Did the reply match specific asks? |
| Completeness | Were all requirements addressed? |
| Quality | Is the response technically correct? |
| Activation depth | Did the model engage deeper reasoning than baseline? |

### Phase 4: Analysis
- Layer contribution matrix: score drop when each layer removed
- Model sensitivity: which architectures benefit most from LAP
- Task interaction: which layers matter for code vs analysis
- Cost-benefit: token overhead per layer vs quality delta
- Final recommendation: optimal layer set per task type

## Total Calls

| Phase | Calls | Est. Cost |
|-------|:---:|:---:|
| Phase 0: Baselines | 15 | ~$1 |
| Phase 1: Full LAP | 21 | ~$2 |
| Phase 2: Ablation | 126 | ~$8 |
| Phase 3: Grading | 3 agents | ~$3 |
| **Total** | **162 + grading** | **~$14** |

## Full LAP Templates

### Simple Task (Debounce) — Full LAP

```
PRIME: typescript, generic-functions, timer-management, higher-order-functions, debounce-vs-throttle
ROLE: You are implementing a production utility function for a shared library. Correctness and type safety matter more than brevity.
FOCUS: [type-preservation, this-context, timer-lifecycle, cancel-semantics, flush-edge-cases]
ACTIVATE: generic-type-inference, defensive-null-handling, edge-case-reasoning
SUPPRESS: over-engineering, unnecessary-abstraction, explanatory-prose, usage-examples
ANCHOR:
  // Existing pattern in the codebase:
  function throttle<T extends (...args: any[]) => any>(fn: T, limit: number): T & { cancel(): void } {
    let timer: ReturnType<typeof setTimeout> | undefined
    return Object.assign(function(this: any, ...args: Parameters<T>) { ... }, { cancel() { ... } }) as T & { cancel(): void }
  }
TASK: Write a TypeScript debounce function. Takes (fn, delay), returns a debounced version with cancel() and flush() methods. Resets timer on each call. No external dependencies. Handle this context correctly. Preserve parameter types via generics.
SHAPE: Code only. No explanation, no usage examples.
```

### Medium Task (WebSocket) — Full LAP

```
PRIME: websocket, finite-state-machine, exponential-backoff, jitter, heartbeat-ping-pong, event-emitter, reconnection-strategy
ROLE: You are building a production WebSocket client library that must handle real-world network conditions — partial failures, stale connections, race conditions between timers and callbacks.
FOCUS: [state-transition-validity, backoff-correctness, heartbeat-detection, stale-callback-prevention, timer-cleanup]
ACTIVATE: formal-state-validation, guard-invalid-transitions, race-condition-awareness, defensive-timer-cleanup
SUPPRESS: happy-path-only-thinking, informal-state-management, missing-edge-cases, untyped-events
ANCHOR:
  type State = "disconnected" | "connecting" | "connected" | "waiting" | "disconnecting" | "failed"
  // Valid transitions:
  // disconnected->connecting:connect(), connecting->connected:ws.onopen,
  // connecting->waiting:ws.onerror|timeout, waiting->connecting:backoff_expired,
  // waiting->failed:retries>=max, connected->disconnecting:close(),
  // connected->waiting:ws.onclose|heartbeat_timeout, disconnecting->disconnected:ws.onclose
TASK: Implement a WebSocket reconnection handler as a TypeScript class. 6 states (disconnected, connecting, connected, waiting, disconnecting, failed). 8 transitions as shown above. Exponential backoff with jitter (base 1s, max 30s). Heartbeat ping every 30s, pong timeout 10s. Configurable max retries, default 10. Typed event emitter for state changes, messages, errors.
SHAPE: Full TypeScript implementation with types.
```

### Complex Task (Rate Limiting) — Full LAP

```
PRIME: distributed-systems, fixed-window-counter, round-robin-load-balancer, per-instance-state, window-boundary-exploit
ROLE: You are a distributed systems engineer tracing a production failure. You must explain the exact mechanism of each failure mode — step by step, with timing, showing what happens on each instance.
FOCUS: [per-instance-counter-behavior, timing-at-window-boundaries, fix-architecture-without-centralized-store, multi-dimensional-tradeoff-analysis]
ACTIVATE: step-by-step-trace-through-instances, quantitative-reasoning, timing-diagrams, concrete-request-counting, formula-derivation
SUPPRESS: surface-level-problem-labeling, hand-waving, "it-depends", premature-solution-before-diagnosis, single-dimensional-tradeoffs
ANCHOR:
  // System state at any moment:
  // instance_A.counter["1.2.3.4"] = 73   (local to A, invisible to B-E)
  // instance_B.counter["1.2.3.4"] = 68   (local to B, invisible to A,C-E)
  // instance_C.counter["1.2.3.4"] = 81   (local to C, invisible to A-B,D-E)
  // ... each instance tracks its own count independently
  // LB routes req #1 -> A, req #2 -> B, req #3 -> C, req #4 -> D, req #5 -> E, req #6 -> A, ...
TASK: A REST API runs on 5 instances behind a round-robin load balancer. Each instance has its own in-memory fixed-window rate limiter: 100 requests/minute per client IP. Clients can make ~500 requests/min before being throttled (5x the intended limit). At window boundaries (minute rollover), clients burst ~1000 requests through. Explain both root causes with exact mechanisms. Propose a fix that does NOT require Redis or any centralized store. Compare tradeoffs of your fix vs centralized Redis.
SHAPE: Causes with step-by-step mechanism traces. Fix with architecture. Tradeoffs as multi-dimensional comparison table.
```

## Ablation Design

For each task, 6 variants remove one layer while keeping all others intact.
Example — Complex task, LAP−SUPPRESS: identical to full LAP but the SUPPRESS
line is deleted entirely. If the score drops, SUPPRESS is load-bearing for
analysis tasks. If it stays the same, SUPPRESS is ceremony.

## Config

| Setting | Type | Default |
|---------|------|---------|
| OPENROUTER_KEY | env var | required |
| GEMINI_API_KEY | env var | required |
| MAX_OUTPUT_TOKENS | int | 2500 |
| TEMPERATURE | float | 0.3 |
| PARALLEL_WORKERS | int | 6 (API), 1 (CLI) |
| TIMEOUT_API | ms | 180000 |
| TIMEOUT_CLI | ms | 300000 |

## Error Handling

| Scenario | Behavior |
|----------|----------|
| API call fails | Retry once after 5s, then record error and continue |
| CLI timeout | Record timeout, skip model for that variant |
| Model returns empty | Record as 0/15 score, flag in analysis |
| Budget exceeded | Stop ablation at current phase, report partial results |

## Scope

**In scope:**
- Full LAP templates for 3 tasks
- Markdown baselines for 5 new models
- 7-model × 3-task × 6-variant ablation
- 5-axis grading by Opus agents
- Layer contribution analysis
- Design summary, spec, and research documentation

**Out of scope:**
- Integration with Foreman or any other system
- Multi-turn LAP (brief → rejection → re-brief)
- Automated layer selection logic
- Production deployment
- New task design (using existing tasks for baseline comparability)

## Open Items

None blocking. All decisions resolved.
