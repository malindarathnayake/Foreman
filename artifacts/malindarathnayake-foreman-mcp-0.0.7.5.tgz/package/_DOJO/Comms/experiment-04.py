"""
Experiment 04 — Markdown vs Seed vs TOON across Codex, Sonnet4.6, GPT-4.1, Gemini-3-Pro
Evaluation: Opus agents grade communication FIDELITY (was intent understood + reply on target)
"""

import json, urllib.request, subprocess, os, time, sys
from concurrent.futures import ThreadPoolExecutor, as_completed

GEMINI_KEY = "AIzaSyBTIMervuFYGAS2NOCWojBuxZo0AEBLH4Y"
OPENROUTER_KEY = "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"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ═══════════════════════════════════════════════════════════════════════════
# TASKS — 3 formats each (markdown, seed, toon)
# ═══════════════════════════════════════════════════════════════════════════

TASKS = {
  "simple": {
    "name": "Debounce Function",
    "markdown": """Write a TypeScript debounce function.

Requirements:
- Generic: works with any function signature
- Returns debounced version that delays invocation by `delay` ms
- Resets timer on each call
- Include cancel() and flush() methods on returned function
- Properly typed (preserve original function's parameter types)
- No external dependencies, handle `this` context correctly

Reply with just the code.""",

    "seed": """TASK: implement debounce<T>
LANG: typescript
SHAPE: (fn: T extends (...args: any[]) => any, delay: number) => T & { cancel(): void, flush(): void }
BEHAVIOR: {
  call -> reset_timer(delay) -> invoke_after_timeout,
  cancel -> clear_timer,
  flush -> invoke_immediately + clear_timer
}
CONSTRAINT: no_deps, preserve_this, preserve_param_types
REPLY: {code}""",

    "toon": """#TOON/1
@F debounce|typescript|generic-function|timer-reset
@S implementation
@A type-safety|behavior|api-surface

@Δa create::debounce+bof
  (fn: T, delay: number) => T & { cancel(): void, flush(): void }

@! must::preserve_this_context
@! must::preserve_param_types(generics)
@! must::reset_timer_on_each_call
@! must::cancel_clears_pending
@! must::flush_invokes_immediately_then_clear
@! must_not::external_dependencies

@? {code}
@σ 0.9
@~ TypeScript debounce with cancel/flush, generic types, this-context preservation."""
  },

  "medium": {
    "name": "WebSocket Reconnection State Machine",
    "markdown": """Design and implement a WebSocket reconnection handler as a TypeScript class.

States: DISCONNECTED, CONNECTING, CONNECTED, WAITING, DISCONNECTING, FAILED (terminal)

Transitions:
- DISCONNECTED -> CONNECTING: user calls connect()
- CONNECTING -> CONNECTED: on WebSocket open
- CONNECTING -> WAITING: on error or timeout
- WAITING -> CONNECTING: when backoff timer expires
- WAITING -> FAILED: when max retries exhausted
- CONNECTED -> DISCONNECTING: user calls close()
- CONNECTED -> WAITING: on unexpected close or heartbeat timeout
- DISCONNECTING -> DISCONNECTED: on close confirmed

Requirements:
- Exponential backoff with jitter (base 1s, max 30s)
- Configurable max retries (default 10)
- Heartbeat: ping every 30s, timeout after 10s with no pong
- Event emitter for state changes, messages, errors
- TypeScript with full types

Reply with the implementation.""",

    "seed": """TOPIC: websocket_reconnection
TYPE: state_machine + implementation

STATES: [disconnected, connecting, connected, waiting, disconnecting, failed(terminal)]
TRANSITIONS: {
  disconnected -> connecting: connect(),
  connecting -> connected: ws.onopen,
  connecting -> waiting: ws.onerror | timeout,
  waiting -> connecting: backoff_expired,
  waiting -> failed: retries >= max,
  connected -> disconnecting: close(),
  connected -> waiting: ws.onclose | heartbeat_timeout,
  disconnecting -> disconnected: ws.onclose
}
BEHAVIOR: {
  backoff: exponential(base=1s, max=30s) + jitter(rand(0,1)*delay),
  heartbeat: ping(30s) -> expect_pong(10s) -> else waiting,
  retries: config(default=10)
}
EVENTS: on(state_change | message | error)
LANG: typescript, full types
REPLY: {implementation_code}""",

    "toon": """#TOON/1
@F websocket|state-machine|exponential-backoff|reconnection
@S src/ws-reconnect.ts
@A states|transitions|backoff|heartbeat|events

@Δa create::WebSocketReconnector+bof

@! must::states(disconnected|connecting|connected|waiting|disconnecting|failed)
@! must::transition(disconnected->connecting:connect())
@! must::transition(connecting->connected:ws.onopen)
@! must::transition(connecting->waiting:ws.onerror|timeout)
@! must::transition(waiting->connecting:backoff_expired)
@! must::transition(waiting->failed:retries>=max)
@! must::transition(connected->disconnecting:close())
@! must::transition(connected->waiting:ws.onclose|heartbeat_timeout)
@! must::transition(disconnecting->disconnected:ws.onclose)
@! must::backoff(exponential,base=1s,max=30s,jitter=random)
@! must::heartbeat(ping=30s,pong_timeout=10s)
@! must::events(state_change|message|error)
@! prefer::max_retries(configurable,default=10)

@E state_type::
  type State = "disconnected"|"connecting"|"connected"|"waiting"|"disconnecting"|"failed"

@? {implementation_code, types}
@σ 0.85
@~ WebSocket reconnection: 6-state machine, exp backoff+jitter, heartbeat, typed events. TypeScript."""
  },

  "complex": {
    "name": "Distributed Rate Limiting Analysis",
    "markdown": """A REST API runs on 5 instances behind a round-robin load balancer. Each instance runs its own in-memory fixed-window rate limiter: 100 requests/minute per client IP.

Observed Problem:
- Clients can make ~500 requests/min before being throttled (5x the intended limit)
- At window boundaries (minute rollover), clients burst ~1000 requests through

Questions:
1. Explain the root cause of the 5x over-admission (explain the mechanism, not just label it)
2. Explain why window boundaries allow the ~1000 burst
3. Propose a fix that does NOT require a centralized store like Redis
4. Compare tradeoffs of your fix vs centralized Redis approach

Be specific about mechanisms, not just labels.""",

    "seed": """ANALYZE: distributed_rate_limit_failure
SYSTEM: {
  instances: 5, lb: round_robin,
  limiter: fixed_window(100/min, per_client_ip, in_memory_per_instance),
  expected: 100 req/min/client,
  observed: ~500 req/min steady, ~1000 at window_boundary
}
SYMPTOM: 5x over-admission + boundary_burst(2x on top)
FIND: {
  1: root_cause(5x_over),
  2: root_cause(boundary_burst),
  3: fix(constraint: no_centralized_store),
  4: tradeoff(your_fix vs redis)
}
DEPTH: explain_mechanism, not_just_label
REPLY: {causes[], fix, tradeoffs}""",

    "toon": """#TOON/1
@F distributed-systems|rate-limiting|fixed-window|load-balancer
@S analysis
@A root-cause|boundary-exploit|fix-design|tradeoffs

@? analyze
  5 instances, round-robin LB
  Each: in-memory fixed-window 100/min/client_ip
  Expected: 100 req/min/client
  Observed: ~500 steady, ~1000 at window boundary

@! must::explain_mechanism(5x_over_admission: not_just_label)
@! must::explain_mechanism(boundary_burst_to_1000: show_timing)
@! must::propose_fix(no_centralized_store)
@! must::tradeoff(your_fix vs redis: multi-dimensional)
@! must_not::surface_level_labels_without_mechanism

@σ 0.7
@~ Why do 5 independent rate limiters allow 5x over-admission? Why 2x more at window boundaries? Fix without Redis. Compare tradeoffs."""
  }
}

# ═══════════════════════════════════════════════════════════════════════════
# API CALLERS
# ═══════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = "You are a senior software engineer. Be concise and direct."

def call_openrouter(prompt, model):
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3, "max_tokens": 2500
    }).encode()
    req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions",
        data=body, headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {OPENROUTER_KEY}"
        })
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - t0
    text = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    return {
        "text": text,
        "tokens_in": usage.get("prompt_tokens", len(prompt)//4),
        "tokens_out": usage.get("completion_tokens", len(text)//4),
        "elapsed_s": round(elapsed, 1)
    }

def call_gemini(prompt, model="gemini-3-pro-preview"):
    body = json.dumps({
        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 2500}
    }).encode()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={GEMINI_KEY}"
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - t0
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    usage = data.get("usageMetadata", {})
    return {
        "text": text,
        "tokens_in": usage.get("promptTokenCount", len(prompt)//4),
        "tokens_out": usage.get("candidatesTokenCount", len(text)//4),
        "elapsed_s": round(elapsed, 1)
    }

def call_codex(prompt):
    t0 = time.time()
    result = subprocess.run(
        ["codex", "exec", "--full-auto", prompt],
        capture_output=True, text=True, timeout=180,
        cwd=OUT_DIR
    )
    elapsed = time.time() - t0
    text = result.stdout.strip()
    if result.returncode != 0 and not text:
        text = f"[CODEX ERROR] rc={result.returncode}\nstderr: {result.stderr[:500]}"
    return {
        "text": text,
        "tokens_in": len(prompt) // 4,
        "tokens_out": len(text) // 4,
        "elapsed_s": round(elapsed, 1)
    }

def call_gemini_cli(prompt):
    t0 = time.time()
    result = subprocess.run(
        ["gemini", "-p", prompt],
        capture_output=True, text=True, timeout=180,
        cwd=OUT_DIR
    )
    elapsed = time.time() - t0
    text = result.stdout.strip()
    if result.returncode != 0 and not text:
        text = f"[GEMINI CLI ERROR] rc={result.returncode}\nstderr: {result.stderr[:500]}"
    return {
        "text": text,
        "tokens_in": len(prompt) // 4,
        "tokens_out": len(text) // 4,
        "elapsed_s": round(elapsed, 1)
    }

# ═══════════════════════════════════════════════════════════════════════════
# MODEL CONFIGS
# ═══════════════════════════════════════════════════════════════════════════

MODELS = {
    "codex":      {"caller": "codex",       "model": None,                        "label": "Codex-CLI"},
    "gemini_cli": {"caller": "gemini_cli",  "model": None,                        "label": "Gemini-CLI"},
    "sonnet":     {"caller": "openrouter",  "model": "anthropic/claude-sonnet-4.6","label": "Sonnet-4.6"},
    "gpt":        {"caller": "openrouter",  "model": "openai/gpt-4.1",            "label": "GPT-4.1"},
}

FORMATS = ["markdown", "seed", "toon"]

# ═══════════════════════════════════════════════════════════════════════════
# RUNNER
# ═══════════════════════════════════════════════════════════════════════════

def run_one(task_key, fmt, model_key):
    task = TASKS[task_key]
    model = MODELS[model_key]
    prompt = task[fmt]
    label = f"{model['label']}|{task_key}|{fmt}"

    try:
        if model["caller"] == "codex":
            result = call_codex(prompt)
        elif model["caller"] == "gemini_cli":
            result = call_gemini_cli(prompt)
        elif model["caller"] == "openrouter":
            result = call_openrouter(prompt, model["model"])
        else:
            result = call_gemini(prompt, model["model"])

        return {
            "label": label,
            "model": model["label"],
            "task": task_key,
            "task_name": task["name"],
            "format": fmt,
            "input": prompt,
            "prompt_tokens": result["tokens_in"],
            "response_tokens": result["tokens_out"],
            "elapsed_s": result["elapsed_s"],
            "response": result["text"],
            "error": None
        }
    except Exception as e:
        return {
            "label": label,
            "model": model["label"],
            "task": task_key,
            "task_name": task["name"],
            "format": fmt,
            "input": prompt,
            "prompt_tokens": 0,
            "response_tokens": 0,
            "elapsed_s": 0,
            "response": "",
            "error": str(e)[:200]
        }

def main():
    jobs = []
    for task_key in TASKS:
        for fmt in FORMATS:
            for model_key in MODELS:
                jobs.append((task_key, fmt, model_key))

    print(f"Running {len(jobs)} calls: {len(TASKS)} tasks x {len(FORMATS)} formats x {len(MODELS)} models")
    print(f"Models: {', '.join(m['label'] for m in MODELS.values())}")
    print(f"Formats: {', '.join(FORMATS)}")
    print()

    # CLIs run sequentially (spawn subprocesses), APIs in parallel
    cli_jobs = [j for j in jobs if j[2] in ("codex", "gemini_cli")]
    api_jobs = [j for j in jobs if j[2] not in ("codex", "gemini_cli")]

    results = []

    # APIs in parallel
    print("── API calls (parallel) ──")
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = {pool.submit(run_one, *j): j for j in api_jobs}
        for future in as_completed(futures):
            r = future.result()
            status = "OK" if not r["error"] else f"ERR: {r['error'][:50]}"
            print(f"  {r['label']:40s} {status:>12s}  {r['elapsed_s']:>5.1f}s  {r['response_tokens']:>5}tok")
            results.append(r)

    # CLIs sequentially
    print(f"\n── CLI calls (sequential, {len(cli_jobs)} total) ──")
    for j in cli_jobs:
        r = run_one(*j)
        status = "OK" if not r["error"] else f"ERR: {r['error'][:50]}"
        print(f"  {r['label']:40s} {status:>12s}  {r['elapsed_s']:>5.1f}s  {r['response_tokens']:>5}tok")
        results.append(r)

    # Save
    results_path = os.path.join(OUT_DIR, "experiment-04-results.json")
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    # Summary
    print(f"\nSaved {len(results)} results to experiment-04-results.json")
    ok = sum(1 for r in results if not r["error"])
    err = sum(1 for r in results if r["error"])
    print(f"Success: {ok}/{len(results)}  Errors: {err}")

    print("\n" + "=" * 100)
    print(f"{'Model':<15} {'Task':<12} {'Format':<10} {'In':>6} {'Out':>6} {'Time':>7} {'Status':<8}")
    print("-" * 100)
    for r in sorted(results, key=lambda x: (x["task"], x["format"], x["model"])):
        s = "OK" if not r["error"] else "ERROR"
        print(f"{r['model']:<15} {r['task']:<12} {r['format']:<10} {r['prompt_tokens']:>6} {r['response_tokens']:>6} {r['elapsed_s']:>6.1f}s {s:<8}")
    print("=" * 100)

    # Format token comparison
    print("\n── Input Token Comparison ──")
    for tk in TASKS:
        toks = {f: len(TASKS[tk][f])//4 for f in FORMATS}
        base = toks["markdown"]
        print(f"  {tk:<12}  md={toks['markdown']:>4}  seed={toks['seed']:>4}({(1-toks['seed']/base)*100:+.0f}%)  toon={toks['toon']:>4}({(1-toks['toon']/base)*100:+.0f}%)")

if __name__ == "__main__":
    main()
