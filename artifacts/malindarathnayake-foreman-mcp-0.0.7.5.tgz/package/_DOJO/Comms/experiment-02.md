# Experiment 02 — Code-as-Protocol

## Hypothesis

LLMs share code comprehension as a training prior more deeply than any
custom notation.  A failing test is the densest possible spec because:

1. It IS the expected behavior (no translation from prose)
2. It IS the verification (no separate test command)
3. Both models understand tests natively
4. The code carries its own domain context

## Format: Test + Routing

```
TARGET: src/types.ts
ANCHOR: after WriteLedgerInputSchema
GUARD: !modify WriteLedgerInputSchema, !modify ReadLedgerInputSchema

// Make this test pass:
import { NormalizeReviewInputSchema } from "../src/types"

describe("NormalizeReviewInputSchema", () => {
  it("accepts valid input", () => {
    expect(NormalizeReviewInputSchema.safeParse({
      reviewer: "codex",
      raw_text: "review output"
    }).success).toBe(true)
  })
  it("rejects reviewer > 200", () => {
    expect(NormalizeReviewInputSchema.safeParse({
      reviewer: "x".repeat(201),
      raw_text: "text"
    }).success).toBe(false)
  })
  it("rejects raw_text > 50000", () => {
    expect(NormalizeReviewInputSchema.safeParse({
      reviewer: "ok",
      raw_text: "x".repeat(50001)
    }).success).toBe(false)
  })
})

REPLY: {status, code, files}
```

3 lines of routing. The test IS the spec. The reply shape is declared.
Total metadata overhead: ~30 tokens.

## Evolution from TOON

TOON encoded dimensions as sigils: @F=domain, @A=axes, @Δ=ops...
But for code tasks, the CODE already encodes all those dimensions:
- Domain? Visible from imports and APIs used.
- Axes? Visible from what the test asserts.
- Operations? Implied by "make this pass."
- Constraints? Explicit GUARD line.
- Verification? The test itself.

TOON solved the wrong problem. It compressed the ENVELOPE when the
real density comes from making the PAYLOAD do double duty as both
specification and verification.

## Where TOON-like notation still wins

Non-code communication: design deliberation, architecture review,
constraint negotiation.  When there IS no code to speak for itself,
dimensional sigils are the next best thing.

So the protocol might be:
- Code tasks → test-as-spec (this experiment)
- Design tasks → dimensional encoding (TOON-inspired)
- Review tasks → annotated diff
- Deliberation → claim+evidence+confidence

Each task type gets the encoding that's native to it.
