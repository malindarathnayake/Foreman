# TOON — Terse Operation-Oriented Notation

## The Problem

When LLM-A (pit-boss) delegates a code task to LLM-B (worker), the brief
is currently ~300 tokens of prose markdown.  The worker must *parse*
natural language to reconstruct the intent.  Most of those tokens are
redundant — both models were trained on overlapping corpora and share
massive conceptual manifolds.  A rare token like `discriminated-union`
activates the same neighbourhood in both models — worth ~200 words of
English.

**Goal:** Encode the brief as sparse coordinates in a shared
multi-dimensional space.  The receiver reconstructs the full idea from
these coordinates because its training priors fill the manifold between
them.

## Core Principle

Don't compress language — compress **pointers into shared training priors**.

A TOON brief is NOT a compressed file.  It's a set of **triangulation
points** — each sigil pins one dimension of the idea, and the receiving
model's activation pattern reconstructs everything between them.

## Dimensions (Sigils)

Each `@`-sigil encodes one dimension of the code change.  Together they
form a coordinate in a multi-dimensional space:

```
Sigil   Dim          What it activates in the receiver
─────   ─────────    ────────────────────────────────────────────────
@F      Domain       Training-prior neighbourhood (rare anchors triangulate)
@S      Spatial      File system position + scope boundary
@A      Focus        Which aspects to reason about (type-safety? perf?)
@Δ      Causal       Operation DAG — changes + dependency edges
@!      Constraint   Invariant manifold — what must NOT change
@E      Pattern      Existing code to generalise from (one example → rule)
@C      Context      What anchors alone can't convey (brief prose, ≤1 sentence)
@T      Verify       Proof of correctness — test command
@?      Reply        Expected shape of the worker's response
@σ      Confidence   Where to be careful (0 = uncertain, 1 = locked)
@~      Gloss        Prose fallback if anchors don't activate
```

### Why these sigils?

- `@F` — **Frame**.  3–6 rare terms that pin the domain.  `zod|mcp-tool|discriminated-union` activates TypeScript + validation + MCP concepts in one shot.  Pipe-separated because `|` is a single token in most tokenisers.

- `@Δ` — **Delta**.  Unicode Δ immediately activates "change/diff" circuitry.  The Unicode IS the compression — one glyph replaces "here is the code change you need to make".

- `@σ` — **Sigma**.  Activates "uncertainty/standard-deviation" circuitry.  The worker knows this is a confidence signal without any prose explaining it.

- `@!` — **Constraint**.  Universal "danger/negation" signal.  `@! must_not::modify(X)` is unambiguous.

- `@E` — **Evidence**.  One concrete example is worth 100 words of description.  Show the pattern, the worker generalises.

### Why NOT these alternatives?

- YAML/JSON envelope: adds structural overhead (`{`, `"`, `:`) that doesn't carry semantic weight.  Every `"key":` is wasted tokens.
- XML tags: verbose, and LLMs must track nesting state.
- Plain markdown headers: no sigil grep-ability, ambiguous nesting.
- Binary encoding: not UTF-8, can't be read/debugged, breaks tool passing.

## Wire Format

Plain UTF-8.  One file or one string.  `grep ^@` on any Linux box extracts the skeleton.

```
#TOON/1
@F anchor1|anchor2|anchor3
@S path/to/file1.ts path/to/file2.ts
@A dim1|dim2|dim3

@Δa <op>::<anchor>+<rel>  [deps=<id>,<id>]
  <indented payload — code to insert/replace>
  <each line indented 2 spaces>

@Δb <op>::<anchor>+<rel>  deps=a
  <payload>

@! <must_not|must|prefer>::<scope> <terse rule>

@E <label>::
  <indented code example>

@C One-sentence context if anchors aren't sufficient.

@T <shell command to verify>
@? <JSON shape of expected reply>
@σ <0.0–1.0>
@~ Prose fallback: what this brief means if the sigil format is unfamiliar.
```

### Parsing Rules

1. Lines starting with `#TOON/` are the version header — skip.
2. Lines starting with `@<sigil>` begin a new section.
3. Lines indented with 2 spaces belong to the preceding `@Δ` or `@E` block.
4. `file=` inside a `@Δ` block overrides the primary scope file.
5. Empty lines are cosmetic — ignored by parser.
6. Everything is UTF-8.  No escaping needed except inside JSON (`@?`).

### Operation Types

```
Op        Meaning
───────   ──────────────────────────────────
insert    Add code relative to anchor
replace   Swap anchor's body with payload
delete    Remove anchor (no payload)
create    New file (anchor = filename, rel = bof)
```

### Anchor Relations

```
Rel       Meaning
───────   ──────────────────────────────────
after     Insert after the anchor
before    Insert before the anchor
replace   Replace the anchor itself
inside    Insert inside the anchor's body (e.g. class/function)
eof       End of file
bof       Beginning of file
```

### Constraint Kinds

```
Kind       Meaning
────────   ──────────────────────────────────
must_not   Hard constraint — violation = rejection
must       Required behaviour — absence = rejection
prefer     Soft preference — violation = warning
```

## Worked Example

### Prose Brief (Current — ~300 tokens)

```markdown
## Worker Brief — Unit 1a: NormalizeReviewInputSchema

### Context
You are working on the Foreman MCP server, a TypeScript project that
uses Zod for schema validation.  All schemas are defined in
`foreman-mcp/src/types.ts`.

### Task
Add a new Zod schema called `NormalizeReviewInputSchema` to the types
file.  This schema validates input for the review normalisation tool.

### Location
File: `foreman-mcp/src/types.ts`
Add the new schema after the existing `WriteLedgerInputSchema`
(around line 86).

### Schema Shape
The schema should have these fields:
- `reviewer`: string, max 200 characters
- `raw_text`: string, max 50,000 characters

### Requirements
- Export the schema as a named export
- Export the inferred TypeScript type as well
- Follow the same pattern as existing schemas in the file

### DO NOT
- Do not modify any existing schemas
- Do not add any imports that aren't already present
- Do not change the file structure

### Existing Pattern (for reference)
    export const WriteLedgerInputSchema = z.discriminatedUnion("operation", [...])
    export type WriteLedgerInput = z.infer<typeof WriteLedgerInputSchema>

### Testing
Run: `cd foreman-mcp && npx vitest run tests/writeTools.test.ts`

### Reply Format
When done, report:
- Files you changed
- Whether tests pass
- Any issues encountered
```

### TOON Brief (Proposed — ~100 tokens)

```
#TOON/1
@F zod|mcp-tool|named-export|typescript
@S foreman-mcp/src/types.ts
@A structure|type-safety|export

@Δa insert::WriteLedgerInputSchema+after
  export const NormalizeReviewInputSchema = z.object({
    reviewer: z.string().max(200),
    raw_text: z.string().max(50000),
  })

@Δb insert::NormalizeReviewInputSchema+after  deps=a
  export type NormalizeReviewInput = z.infer<typeof NormalizeReviewInputSchema>

@! must_not::modify(WriteLedgerInputSchema|ReadLedgerInputSchema)
@! must::named_export(NormalizeReviewInputSchema)

@E existing_pattern::
  export const WriteLedgerInputSchema = z.discriminatedUnion("operation", [...])
  export type WriteLedgerInput = z.infer<typeof WriteLedgerInputSchema>

@T cd foreman-mcp && npx vitest run tests/writeTools.test.ts
@? {"files":"string[]","pass":"bool"}
@σ 0.95
```

**Savings: ~65%** — and the TOON version carries MORE structural
information (explicit deps, typed constraints, pattern evidence).

## Multi-Op Example (Complex Unit)

A unit that touches 3 files with dependency ordering:

```
#TOON/1
@F express|middleware|zod-validate|error-boundary
@S src/routes/api.ts src/middleware/validate.ts src/types/api.ts
@A request-flow|type-safety|error-handling

@Δa create::api.ts+bof
  file=src/types/api.ts
  import { z } from "zod"
  export const CreateUserSchema = z.object({
    name: z.string().min(1).max(100),
    email: z.string().email(),
    role: z.enum(["admin", "user"]),
  })
  export type CreateUserInput = z.infer<typeof CreateUserSchema>

@Δb insert::errorHandler+before  deps=a
  file=src/middleware/validate.ts
  export function validate(schema: z.ZodSchema) {
    return (req: Request, _res: Response, next: NextFunction) => {
      schema.parse(req.body)
      next()
    }
  }

@Δc insert::router.get("/users")+before  deps=a,b
  router.post("/users", validate(CreateUserSchema), async (req, res) => {
    const input = CreateUserSchema.parse(req.body)
    const user = await createUser(input)
    res.status(201).json(user)
  })

@! must_not::modify(existing-routes)
@! must::validate-before-handler(CreateUserSchema)
@! prefer::early-return-on-error

@E route_pattern::
  router.get("/users", async (req, res) => { ... })

@C Zod parse throws ZodError — existing errorHandler already catches it.

@T cd src && npm test -- --grep "POST /users"
@? {"files":"string[]","pass":"bool","routes_added":"number"}
@σ 0.85
@~ Add a POST /users route with Zod input validation. Schema in types/api.ts, validator middleware in middleware/validate.ts, route in routes/api.ts.
```

## Why This Works (Theory)

### Shared Manifold Activation

Both Opus and Sonnet were trained on:
- Millions of TypeScript files → they "know" Zod, know type inference,
  know export patterns
- Millions of git diffs → they understand insert/replace/delete as
  code operations
- AST structures → they understand code as a tree, not just text
- Test frameworks → they know vitest, jest, mocha assertion patterns

A token like `zod` doesn't just mean "the library" — it activates:
- Schema definition patterns
- `.parse()` / `.safeParse()` usage
- Type inference with `z.infer<>`
- Error handling (ZodError)
- Composability (`.extend()`, `.merge()`, `.pick()`)

That's the manifold.  `@F zod` points at the centre of it.  The
worker fills in the details from its own priors.

### Triangulation

Single anchors risk drift — `zod` alone could activate testing
patterns, migration patterns, form validation patterns.  Multiple
anchors triangulate: `zod|mcp-tool|named-export` narrows to "Zod
schemas in an MCP server, exported by name".  That's a very specific
region.

Rule of thumb: **3 anchors minimum, 6 maximum**.  Below 3 = ambiguous.
Above 6 = diminishing returns (you're writing prose with pipes).

### Evidence as Compression

`@E existing_pattern::` followed by 2 lines of code is worth paragraphs
of explanation.  The worker sees the pattern, activates its
"generalise from example" circuitry, and produces code that follows
the same shape.  This is strictly more information-dense than
describing the pattern in words.

## Drift Risks & Mitigations

| Risk | What happens | Mitigation |
|------|-------------|------------|
| Anchor miss | Rare term activates wrong manifold | Redundant anchors (3+ per concept, triangulate) |
| Payload ambiguity | Indentation misread | 2-space indent is universal in TS/JS training data |
| Op misfire | Worker modifies wrong anchor | `@!` constraints act as guardrails |
| Model divergence | Opus/Sonnet interpret format differently | `@~` gloss provides prose fallback |
| Version skew | Future TOON versions break parser | `#TOON/1` version header, schema validation |

## Token Budget Analysis

| Component | Prose (tokens) | TOON (tokens) | Savings |
|-----------|---------------|---------------|---------|
| Context/domain | ~50 | ~10 (@F, @S, @A) | 80% |
| Task description | ~40 | 0 (implicit in @Δ) | 100% |
| Location info | ~30 | ~5 (@Δ anchor) | 83% |
| Code payload | ~40 | ~40 (same) | 0% |
| Requirements | ~30 | ~10 (@!) | 67% |
| DO NOT list | ~30 | ~8 (@!) | 73% |
| Existing pattern | ~40 | ~15 (@E) | 63% |
| Testing | ~20 | ~10 (@T, @?) | 50% |
| Reply format | ~20 | ~5 (@?) | 75% |
| **Total** | **~300** | **~103** | **~66%** |

The savings come from eliminating **framing prose** — the words that
explain what each section IS rather than what it CONTAINS.  In prose:
"### Requirements" + "Export the schema as a named export" = ~10 tokens.
In TOON: `@! must::named_export(X)` = ~5 tokens.  Multiply across
every section.

The **code payload** doesn't compress — it's already in its densest
form.  TOON compresses the **envelope**, not the content.

## Open Questions

1. **Should the worker reply in TOON format too?**
   Pro: pit-boss can machine-parse the response.
   Con: pit-boss already validates by reading files + running tests.
   Leaning: No for PoC.  The asymmetry is intentional — the brief
   needs to be dense (many workers, each gets one), but the reply
   only happens once per unit.

2. **Should @E be mandatory or optional?**
   Evidence dramatically improves worker accuracy but costs tokens.
   Maybe: mandatory for `insert`, optional for `replace`/`delete`.

3. **How to handle multi-line @C (context)?**
   Current spec: single line.  If context needs more, use `@~` gloss
   instead (which is explicitly prose).  Keep `@C` terse.

4. **Should deps be cross-unit or only intra-brief?**
   Current: intra-brief only (deps=a,b reference ops in the same TOON).
   Cross-unit ordering is the ledger's job.  Keep separation of concerns.

5. **What about conditional ops?**
   "If file has X, do Y; otherwise do Z" — prose is better here.
   TOON is for deterministic ops.  Conditional logic → `@~` gloss or
   separate briefs.

6. **Minimum viable test: does Sonnet follow TOON cold?**
   The real validation is: hand a TOON brief to Sonnet (no preamble,
   no explanation of the format) and see if it produces correct code.
   If yes → the format works.  If no → anchors need tuning or `@~`
   gloss becomes mandatory.
