"""
Experiment 03 — Seed Pattern vs Compact Markdown
Across models: Sonnet×2, GPT (OpenRouter), Gemini 3 Pro
Across complexity: simple code, medium design, complex analysis
"""

import json, urllib.request, os, time
from concurrent.futures import ThreadPoolExecutor, as_completed

GEMINI_KEY = "AIzaSyBTIMervuFYGAS2NOCWojBuxZo0AEBLH4Y"
OPENROUTER_KEY = "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"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ─── Tasks ──────────────────────────────────────────────────────────────────

TASKS = {
    "simple": {
        "name": "Debounce Function",
        "markdown": """## Task
Write a TypeScript `debounce` function.

### Requirements
- Generic: works with any function signature
- Returns a debounced version that delays invocation by `delay` ms
- Resets timer on each call
- Include `cancel()` and `flush()` methods on returned function
- Properly typed (preserve original function's parameter types)

### Constraints
- No external dependencies
- Must handle `this` context correctly

Reply with just the code.""",

        "seed": """TASK: implement debounce<T>
LANG: typescript
SHAPE: (fn: T extends (...args: any[]) => any, delay: number) => T & { cancel(): void, flush(): void }
BEHAVIOR: {
  call -> reset_timer(delay) -> invoke_after_timeout,
  cancel -> clear_timer,
  flush -> invoke_immediately + clear_timer
}
CONSTRAINT: no_deps, preserve_this, preserve_param_types
REPLY: {code}"""
    },

    "medium": {
        "name": "WebSocket Reconnection State Machine",
        "markdown": """## Task
Design and implement a WebSocket reconnection handler as a TypeScript class.

### State Machine
States: DISCONNECTED, CONNECTING, CONNECTED, WAITING, DISCONNECTING, FAILED (terminal)

Transitions:
- DISCONNECTED → CONNECTING: when user calls connect()
- CONNECTING → CONNECTED: on WebSocket open
- CONNECTING → WAITING: on error or timeout
- WAITING → CONNECTING: when backoff timer expires
- WAITING → FAILED: when max retries exhausted
- CONNECTED → DISCONNECTING: when user calls close()
- CONNECTED → WAITING: on unexpected close or heartbeat timeout
- DISCONNECTING → DISCONNECTED: on close confirmed

### Requirements
- Exponential backoff with jitter (base 1s, max 30s)
- Configurable max retries (default 10)
- Heartbeat: ping every 30s, timeout after 10s with no pong
- Event emitter for state changes, messages, errors
- TypeScript with full types

Reply with the implementation.""",

        "seed": """TOPIC: websocket_reconnection
TYPE: state_machine + implementation

STATES: [disconnected, connecting, connected, waiting, disconnecting, failed(terminal)]
TRANSITIONS: {
  disconnected -> connecting: connect(),
  connecting -> connected: ws.onopen,
  connecting -> waiting: ws.onerror | timeout,
  waiting -> connecting: backoff_expired,
  waiting -> failed: retries >= max,
  connected -> disconnecting: close(),
  connected -> waiting: ws.onclose | heartbeat_timeout,
  disconnecting -> disconnected: ws.onclose
}
BEHAVIOR: {
  backoff: exponential(base=1s, max=30s) + jitter(rand(0,1)*delay),
  heartbeat: ping(30s) -> expect_pong(10s) -> else waiting,
  retries: config(default=10)
}
EVENTS: on(state_change | message | error)
LANG: typescript, full types
REPLY: {implementation_code}"""
    },

    "complex": {
        "name": "Distributed Rate Limiting Analysis",
        "markdown": """## Analysis Task
A REST API runs on 5 instances behind a round-robin load balancer. Each instance runs its own in-memory fixed-window rate limiter: 100 requests/minute per client IP.

### Observed Problem
- Clients can make ~500 requests/min before being throttled (5x the intended limit)
- At window boundaries (e.g., minute rollover), clients sometimes burst ~1000 requests through

### Questions
1. Explain the root cause of the 5x over-admission
2. Explain why window boundaries allow even more (the ~1000 burst)
3. Propose a fix that does NOT require a centralized store like Redis
4. Compare tradeoffs of your fix vs centralized Redis approach

Be specific about mechanisms, not just labels.""",

        "seed": """ANALYZE: distributed_rate_limit_failure
SYSTEM: {
  instances: 5, lb: round_robin,
  limiter: fixed_window(100/min, per_client_ip, in_memory_per_instance),
  expected: 100 req/min/client,
  observed: ~500 req/min steady, ~1000 at window_boundary
}
SYMPTOM: 5x over-admission + boundary_burst(2x on top)
FIND: {
  1: root_cause(5x_over),
  2: root_cause(boundary_burst),
  3: fix(constraint: no_centralized_store),
  4: tradeoff(your_fix vs redis)
}
DEPTH: explain_mechanism, not_just_label
REPLY: {causes[], fix, tradeoffs}"""
    }
}

# ─── API Callers ────────────────────────────────────────────────────────────

def call_openrouter(prompt, model, system="You are a senior software engineer. Be concise and direct."):
    url = "https://openrouter.ai/api/v1/chat/completions"
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 2500
    }).encode()
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {OPENROUTER_KEY}"
    })
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - t0
    text = data["choices"][0]["message"]["content"]
    usage = data.get("usage", {})
    return {
        "text": text,
        "tokens_in": usage.get("prompt_tokens", len(prompt) // 4),
        "tokens_out": usage.get("completion_tokens", len(text) // 4),
        "elapsed_s": round(elapsed, 1)
    }

def call_gemini(prompt, model="gemini-3-pro-preview", system="You are a senior software engineer. Be concise and direct."):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={GEMINI_KEY}"
    body = json.dumps({
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 2500}
    }).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - t0
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    usage = data.get("usageMetadata", {})
    return {
        "text": text,
        "tokens_in": usage.get("promptTokenCount", len(prompt) // 4),
        "tokens_out": usage.get("candidatesTokenCount", len(text) // 4),
        "elapsed_s": round(elapsed, 1)
    }

# ─── Model configs ──────────────────────────────────────────────────────────

MODELS = {
    "sonnet_a": {"caller": "openrouter", "model": "anthropic/claude-sonnet-4.5", "label": "Sonnet4.5-A"},
    "sonnet_b": {"caller": "openrouter", "model": "anthropic/claude-sonnet-4.6", "label": "Sonnet4.6-B"},
    "gpt":      {"caller": "openrouter", "model": "openai/gpt-4.1",             "label": "GPT-4.1"},
    "gemini":   {"caller": "gemini",     "model": "gemini-3-pro-preview",        "label": "Gemini-3-Pro"},
}

# ─── Run experiment ─────────────────────────────────────────────────────────

def run_one(task_key, fmt, model_key):
    task = TASKS[task_key]
    model = MODELS[model_key]
    prompt = task["markdown"] if fmt == "markdown" else task["seed"]
    label = f"{model['label']}|{task_key}|{fmt}"

    try:
        if model["caller"] == "openrouter":
            result = call_openrouter(prompt, model["model"])
        else:
            result = call_gemini(prompt, model["model"])
        return {
            "label": label,
            "model": model["label"],
            "task": task_key,
            "task_name": task["name"],
            "format": fmt,
            "prompt_tokens": result["tokens_in"],
            "response_tokens": result["tokens_out"],
            "elapsed_s": result["elapsed_s"],
            "response": result["text"],
            "error": None
        }
    except Exception as e:
        return {
            "label": label,
            "model": model["label"],
            "task": task_key,
            "task_name": task["name"],
            "format": fmt,
            "prompt_tokens": 0,
            "response_tokens": 0,
            "elapsed_s": 0,
            "response": "",
            "error": str(e)
        }

def main():
    jobs = []
    for task_key in TASKS:
        for fmt in ["markdown", "seed"]:
            for model_key in MODELS:
                jobs.append((task_key, fmt, model_key))

    print(f"Running {len(jobs)} calls across {len(MODELS)} models, {len(TASKS)} tasks, 2 formats...")
    print()

    results = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(run_one, *job): job for job in jobs}
        for future in as_completed(futures):
            r = future.result()
            status = "OK" if not r["error"] else f"ERR: {r['error'][:60]}"
            print(f"  {r['label']:40s} -> {status} ({r['elapsed_s']}s, {r['response_tokens']}tok out)")
            results.append(r)

    # Save full results
    results_path = os.path.join(OUT_DIR, "experiment-03-results.json")
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved {len(results)} results to experiment-03-results.json")

    # Print summary table
    print("\n" + "=" * 90)
    print(f"{'Model':<15} {'Task':<12} {'Format':<10} {'In':>6} {'Out':>6} {'Time':>6} {'Status':<10}")
    print("-" * 90)
    for r in sorted(results, key=lambda x: (x["task"], x["format"], x["model"])):
        status = "OK" if not r["error"] else "ERROR"
        print(f"{r['model']:<15} {r['task']:<12} {r['format']:<10} {r['prompt_tokens']:>6} {r['response_tokens']:>6} {r['elapsed_s']:>5.1f}s {status:<10}")
    print("=" * 90)

    # Print format comparison (prompt tokens)
    print("\n── Prompt Token Comparison (markdown vs seed) ──")
    for task_key in TASKS:
        md_tok = len(TASKS[task_key]["markdown"]) // 4
        seed_tok = len(TASKS[task_key]["seed"]) // 4
        savings = (1 - seed_tok / md_tok) * 100
        print(f"  {task_key:<12} markdown={md_tok:>4}tok  seed={seed_tok:>4}tok  savings={savings:.0f}%")

if __name__ == "__main__":
    main()
